#include <cstdio>
#include <cstring>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <stdlib.h>

using namespace std;

void registration();
void login();
int startingMenu();


// Student Modules
void studentMenu();
void checkCGPA();
void studentProfile();

// Teacher Modules
void teacherMenu();

// Admin Modules
void adminMenu();
void teacherRecords();
void manageClasses();
void teacherApproval();

// Shared modules
void studentRecords();
void manageMarks();
void deleteRecord(string recordType);
void updateRecord(string recordType);
void searchRecord(string recordType);

struct {
	string userID;
	string name;
	string userRole;
	string currentSemester;
	bool loginStatus;
} userInfo;


int main(){
	int choice;
	userInfo.loginStatus = false;
	
	choice = startingMenu(); // Get choice from startingMenu() module
	
	system("cls"); // Clears console
	
	switch(choice){
		case 1:
			registration();
			break;
			
		case 2:
			login();
			break;
			
		case 3:
			int option;
			
			cout << "Are you sure you want to exit?" << endl;
			cout << "1 - Yes" << endl;
			cout << "2 - No" << endl;
			cout << "====================" << endl;
			cout << "Enter an option: ";
			cin >> option;
			
			if (option == 1){
				cout << "\nThank you for using our system!";
				return 0;
			} else{
				system("cls"); // clears window
				main();
			}

			break;
						
		default:
			system("cls"); // clears window
			cout << "Please enter a valid option." << endl;
			main();
	}
	
}

int startingMenu(){
	
	int choice;
	
	cout << "WELCOME TO STUDENT RESULT MANAGEMENT SYSTEM" << endl;
	cout << "====================" << endl;
	cout << "Option:" << endl;
	cout << "1 - Registration" << endl;
	cout << "2 - Login" << endl;
	cout << "3 - Exit" << endl;
	cout << "====================" << endl;
	cout << "Enter an option: ";
	cin >> choice;
	
	return choice;
	
}


void login(){
	int count=0;
	string userID, ID, password, pass, name, course, semester;
	
	cout << "Logging in.." << endl << endl;
	
	
	cout << "Enter ID (or BACK to go back): " ;
	cin >> userID;
	
	// Turns input uppercase
	for(int i=0;i<userID.length();i++){ 
		userID[i]=toupper(userID[i]);
	}
	
	// If user inputs "BACK", program will return to starting menu
	if (userID == "BACK"){
		system("cls");
		main();
		return;
	}
	
	cout << "Password: ";
	cin >> password;
	
	ifstream studentFile("studentRecords.txt");
    ifstream teacherFile("teacherRecords.txt");
    ifstream adminFile("adminRecords.txt");

	system("cls");
	
    while (studentFile >> ID >> pass >> name >> course >> semester) {
        if (userID == ID && password == pass) {
    		userInfo.userID = ID;
    		userInfo.name = name;
    		userInfo.currentSemester = semester;
    		userInfo.loginStatus = true;
            studentMenu();
            return;
        }
    }

    if (userInfo.loginStatus == false) {
        while (teacherFile >> ID >> pass >> name) {
            if (userID == ID && password == pass) {
              userInfo.userRole = "TEACHER";
			  userInfo.name = name;
              userInfo.loginStatus = true;
			  teacherMenu();
			return;
            }
        }
    }

    if (userInfo.loginStatus == false) {
        while (adminFile >> ID >> pass >> name) {
            if (userID == ID && password == pass) {
            	userInfo.userRole = "ADMIN";
				userInfo.name = name;
            	userInfo.loginStatus = true;
				adminMenu();
				return;

            }
        }
    }

    studentFile.close();
    teacherFile.close();
    adminFile.close();

	if (userInfo.loginStatus == false){
		system("cls");
	
		cout << "ID or password is incorrect!" << endl;
		login();
	}
}


void registration(){
	string RuserID, Rid, Rpassword, REpassword, Rpass, name, course;
	int semester;
	
	cout << "Enter name (or BACK to go back): ";
	cin >> name;
	
	// Turns input uppercase
	for(int i=0;i<name.length();i++){ 
		name[i]=toupper(name[i]);
	}
	
	// If user inputs "BACK", program will return to starting menu
	if (name == "BACK"){
		system("cls");
		main();
		return;
	}
	
	cout << "Enter your ID: ";
	cin >> RuserID;

		
	do{
		cout << "Enter password: ";
		cin >> Rpassword;

		cout << "Re-enter password: ";
		cin >> REpassword;
		
		if (REpassword != Rpassword){
			cout << "Passwords don't match! Try again!" << endl << endl;
		} 
		
	} while (Rpassword != REpassword); // If passwords don't match user has to enter password again
	
	
	// Ask user if they are a teacher
	string registerTeacher;
	cout << "Are you a teacher (YES/NO): ";
	cin >> registerTeacher;
	
	// Turns input uppercase
	for(int i=0;i<registerTeacher.length();i++){ 
		registerTeacher[i]=toupper(registerTeacher[i]);
	}
	
	if (registerTeacher == "YES") {
        // If the user wants to register as a teacher, add record to a seperate file for admin approval
        ofstream approvalFile("teacher_approval_requests.txt", ios::app);
        
        approvalFile << RuserID << " " << Rpassword << " " << name << endl;
        
        approvalFile.close();

		system ("cls");
        cout << "Your registration is pending admin approval. Please contact an admin for further instructions." << endl << endl;
		return;
    } else {
    	
    	cout << "Enter your course (CE/CS/BM): ";
    	cin >> course;
    	
    	for(int i=0;i<course.length();i++){ 
		course[i]=toupper(course[i]);
		}
		
		cout << "Enter your current semester: ";
		cin >> semester;
		
		fstream f1("studentRecords.txt", ios::app);
		
		f1 << RuserID <<" "<< Rpassword << " "<< name << " " << course << " " << semester <<endl;
	
		f1.close();
	}


	system ("cls");
	cout << "Registration successful!" << endl << endl;
	main();
	
}


// ==================== STUDENT MENU ====================

void studentMenu(){
	int choice;
	
	while (userInfo.loginStatus==true){
	
		cout << "WELCOME, "<< userInfo.name << endl;
		cout << "====================" << endl;
		cout << "Option:" << endl;
		cout << "1 - Check CGPA" << endl;
		cout << "2 - Personal Info" << endl;
		cout << "3 - Log out" << endl;
		cout << "====================" << endl;
		cout << "Enter an option: ";
		cin >> choice;
		
		system("cls");
		
		switch(choice){
			case 1:
				checkCGPA();
				break;
				
			case 2:
				studentProfile();
				break;
				
			case 3:
				int option;
				
				cout << "Are you sure you want to log out?"<< endl;
				cout << "1 - Yes" << endl;
				cout << "2 - No" << endl;
				cout << "====================" << endl;
				cout << "Enter an option: ";
				cin >> option;
				
				system("cls");
				
				if (option == 1){
					cout << "Logged out!" << endl << endl;
					userInfo.loginStatus = false;
					main();
					return;
				}
				
				break;
							
			default:
				cout << "Please enter a valid option." << endl << endl;
		}
		
	}
	
}


void checkCGPA(){
	
	cout << "=========================" << endl;
	cout << "CURRENT GPA" << endl;
	cout << "=========================" << endl<< endl;
	
	string option, studentID, ID, subjectName, subjectCode, semester;
	string subName, subCode;
	
    double marks;
    int creditHours;
    
    double currentWeightedScore = 0.0, totalWeightedScore = 0.0;
    int currentCreditHours = 0, totalCreditHours = 0;

    studentID = userInfo.userID;
	
    ifstream marksInput("marks.txt");
    ifstream subjects("subjects.txt");
	
	cout << left<< setw(40) << "Subject" << setw(8) << "Marks" << setw(12) << "Grade Point" << setw(12) << "Credit Hours" << endl << endl;

    while (marksInput >> ID >> subjectCode >> marks >> creditHours >> semester) {
        if (ID == studentID) {
        	
        	while (subjects >> subCode >> subName){
        		if (subCode == subjectCode){
        			subjectName = subName;
        			break;
        		}
        	}

        	// Calculate grade point for subject
        	double gradePoint = marks / 100 * 4;
        	
            // Calculate the weighted score for the subject
            double weightedScore = gradePoint * creditHours;

            // Update total weighted score and total credit hours
            totalWeightedScore += weightedScore;
            totalCreditHours += creditHours;

            // Display the score for each subject
            if (semester == userInfo.currentSemester){
        		currentWeightedScore += weightedScore;	  	
        		currentCreditHours += creditHours;
        		cout << left << setw(10) << subjectCode << setw(30) << subjectName << setw(8) << marks << setw(12) << gradePoint << setw(12) << creditHours << endl;
			
			}
			subjectName = "";
			subjects.seekg(0, ios::beg);
			
   	 	}
	}

    marksInput.close();
    subjects.close();

    // Calculate CGPA based on total weighted score and total credit hours
    if (totalCreditHours > 0) {
    	
    	double GPA = currentWeightedScore / currentCreditHours;
        double CGPA = totalWeightedScore / totalCreditHours;
        
		// Display CGPA with two decimal places
        cout << fixed << setprecision(2);
        cout << "\nTotal Credit Hours: " << currentCreditHours << endl;
        cout << "Current GPA: " << GPA << endl;
        cout << "CGPA: " << CGPA << endl;
    } else {
        cout << "No records found. If there is a mistake please contact an admin." << endl;
    }
    
    cout << "=========================" << endl;
	system("pause");

	system("cls");	
}
	
	
void studentProfile(){
	string option;
		
	cout << "=========================" << endl;
	cout << "USER PROFILE" << endl;
	cout << "=========================" << endl<< endl;
	
    ifstream input("studentRecords.txt");
    ifstream records("marks.txt");
    ifstream subjects("subjects.txt");
    
    string studentID, ID, pass, name, course;
	string sem, subjectName, subjectCode , subName, subCode, marks, creditHours, semester;
    bool found = false;
	
    while (input >> ID >> pass >> name >> course >> semester) {
        if (ID == userInfo.userID) {
        	found = true;
            cout << "Student ID: " << ID << endl;
            cout << "Name: " << name << endl;
            cout << "Course: " << course << endl;
            cout << "Current semester: " << semester << endl << endl;


			cout << "Subjects Taken: " << endl;
			
			while (records >> studentID >> subjectCode >> marks >> creditHours >> sem){
				if (studentID == userInfo.userID && sem == userInfo.currentSemester){
					
					subjects.seekg(0, ios::beg);
					
					while (subjects >> subCode >> subName){

    					if (subCode == subjectCode){
    						subjectName = subName;
    						break;
    					}
        			}
        			
					cout << "  -" << subjectCode << " - " << subjectName << endl;
				
				}		
			}
			
			records.seekg(0, ios::beg);
			subjectName = "";
							
		}
    }

    input.close();
    subjects.close();
    records.close();

    if (!found) {
        cout << "Data not found. Please contact an admin. " << endl << endl;
    }	
	
	
	cout << "=========================" << endl;
	system("pause");
	system("cls");
	
}



// ==================== TEACHER MENU ====================

void teacherMenu(){
	int choice;
	
	while (userInfo.loginStatus == true){
		cout << "WELCOME, " << userInfo.name << endl;
		cout << "=========================" << endl;
		cout << "Option:" << endl;
		cout << "1 - Student Records" << endl;
		cout << "2 - Update student marks" << endl;
		cout << "3 - Log out" << endl;
		cout << "=========================" << endl;
		cout << "Enter an option: ";
		cin >> choice;
		
		system("cls");
		
		switch(choice){
			case 1:
				studentRecords();
				break;
				
			case 2:
				manageMarks();
				break;
				
			case 3:
				int option;
				
				cout << "Are you sure you want to logout?" << endl;
				cout << "1 - Yes" << endl;
				cout << "2 - No" << endl;
				cout << "=========================" << endl;
				cout << "Enter an option: ";
				cin >> option;
				
				system("cls");
				
				if (option == 1){
					cout << "Logged out!" << endl << endl;
					userInfo.loginStatus = false;
					main();
					return;
				}
				break;
			
			default:
				cout << "Please enter a valid option." << endl << endl;
		}
	}		
}


void manageMarks(){
	cout << "=========================" << endl;
	cout << "UPDATE STUDENT MARKS" << endl;
	cout << "=========================" << endl;
	
	string studentID;
    cout << "Enter student ID (or BACK to go back): ";
    cin >> studentID;
    
    // Turns input uppercase
	for (int i=0; i<studentID.length(); i++){ 
		studentID[i]=toupper(studentID[i]);
	}
    
    if (studentID == "BACK"){
    	system("cls");
		return;
	}

    ifstream input("studentRecords.txt");
    string ID, pass, name, course, semester;
    bool found = false;

    while (input >> ID >> pass >> name >> course >> semester) {
        if (ID == studentID) {
            found = true;
            
			cout << "=========================" << endl;
            // Ask for marks and credit hours for each subject
            cout << "Enter marks and credit hours for each subject (type 'done' when finished):" << endl;

            // Open the marks file in append mode
            ofstream marksFile("marks.txt", ios::app);

            while (true) {
                string subject;
                double marks;
                int creditHours;

                cout << "Enter subject code (or type 'DONE' to finish): ";
                cin >> subject;

				// turns input uppercase
				for(int i=0;i<subject.length();i++){ 
					subject[i]=toupper(subject[i]);
				}

				// Exit the loop if the teacher is done entering marks" 
				if (subject == "DONE"){
					system("cls");
					break; 
				}


                cout << "Enter marks for " << subject << ": ";
                cin >> marks;

                cout << "Enter credit hours for " << subject << ": ";
                cin >> creditHours;
                cout << endl;

                // Write the marks and credit hours to the marks file
                marksFile << studentID << " " << subject << " " << marks << " " << creditHours << " " << semester << endl;
            }

            marksFile.close();

            cout << "Marks entered successfully!" << endl;

            break;
        }
    }

    input.close();

    if (!found) {
        cout << "Student not found!" << endl;
    }	
}


// ==================== ADMIN MENU ====================
void adminMenu(){
	int choice ;
	
	while (userInfo.loginStatus == true){
		cout << "WELCOME, " << userInfo.name << endl;
		cout << "=========================" << endl;
		cout << "Option:" << endl;
		cout << "1 - Student Records" << endl;
		cout << "2 - Teacher records" << endl;
		cout << "3 - Manage classes" << endl;
		cout << "4 - Manage students marks" << endl;
		cout << "5 - Approve registration requests" << endl;
		cout << "6 - Log out" << endl;
		cout << "=========================" << endl;
		cout << "Enter an option: ";
		cin >> choice;
		
		system("cls");
		
		switch(choice){
			case 1:
				studentRecords();
				break;
				
			case 2:
				teacherRecords();
				break;
				
			case 3:
				manageClasses();
				break;
				
			case 4:
				manageMarks();
				break;
				
			case 5:
				teacherApproval();
				break;
				
			case 6:
				int option;
				
				cout << "Are you sure you want to log out?" << endl;
				cout << "1 - Yes" << endl;
				cout << "2 - No" << endl;
				cout << "=========================" << endl;
				cout << "Enter an option: ";
				cin >> option;
				
				system("cls");
				
				if (option == 1){
					cout << "Logged out!" << endl << endl;
					userInfo.loginStatus = false;
					main();
					return;
				} else {
					adminMenu();
				}
							
			default:
				cout << "Please enter a valid option." << endl << endl;
		}
	}
}


void studentRecords(){
	int choice;
	
	while (true){
	
		cout << "=========================" << endl;
		cout << "LIST OF STUDENTS" << endl;
		cout << "=========================" << endl;
		
		ifstream input("studentRecords.txt");
		
	    string ID, pass, name, course, semester;
	    int number = 1;  // counter for line numbers
	
	    while (input >> ID >> pass >> name >> course >> semester) {
	        cout << left << setw (3) << number << ".\t" << setw(12) << ID << setw(15) << name << setw(5) << course << endl;
			number++;
	    }
	    
	    input.close();	 
		   
		cout << "=========================" << endl;
		cout << "What would you like to do?" << endl;
		
		if (userInfo.userRole == "ADMIN"){
			cout << "1 - Search Record" << endl;
			cout << "2 - Update record" << endl;
			cout << "3 - Delete record" << endl;
			cout << "4 - Back" << endl;
		} else if (userInfo.userRole == "TEACHER") {
			cout << "1 - Search Record" << endl;
			cout << "2 - Back" << endl;
		}
		
		cout << "=========================" << endl;
		cout << "Enter an option: ";
		cin >> choice;
		
		system("cls");
		
		if (userInfo.userRole == "TEACHER"){
			switch (choice){
				case 1:
					searchRecord("STUDENT");
					break;
				
				case 2:
					return;
					break;
					
					
				default:
					cout << "Please enter a valid option" << endl << endl;
			}	
		}
		
		if (userInfo.userRole == "ADMIN"){
			switch (choice){
				case 1:
					searchRecord("STUDENT");
					break;
				
				case 2:
					updateRecord("STUDENT");
					break;
					
				case 3:
					deleteRecord("STUDENT");
					break;
					
				case 4:
					return;
					break;
					
				default:
					cout << "Please enter a valid option" << endl << endl;
			}	
		}
	}
}
    


void teacherRecords(){
	int choice;
	
	cout << "=========================" << endl;
	cout << "LIST OF TEACHERS" << endl;
	cout << "=========================" << endl;
	

	ifstream input("teacherRecords.txt");
    string ID, pass, name;
    int number = 1;  // Counter for line numbers

    while (input >> ID >> pass >> name) {
        cout << left << setw (3) << number << ".\t" << setw(12) << ID << setw(15) << name<< endl;
		number++;
    }

	input.close();
	
	cout << "=========================" << endl;
	cout << "What would you like to do?" << endl;
	cout << "1 - Search record" << endl;
	cout << "2 - Update record" << endl;
	cout << "3 - Delete record" << endl;
	cout << "4 - Back" << endl;
	cout << "=========================" << endl;
	cout << "Enter an option: ";
	cin >> choice;
	
	switch (choice){
		case 1:
			searchRecord("TEACHER");
			break;
		
		case 2:
			updateRecord("TEACHER");
			break;
			
		case 3:
			deleteRecord("TEACHER");
			break;
			
		case 4:
			system("cls");;
			break;
			
		default:
			cout << "Please enter a valid option" << endl << endl;
		
	}
	
	return;
    
	
}

void manageClasses(){
	system("cls");
	
	int option1, option2;

	while (option1 != 4){
	    cout << "=========================" << endl;
	    cout << "MANAGE CLASSES" << endl;
	    cout << "=========================" << endl;
		cout << "LIST OF CLASSES" << endl;
		cout << "1 - Computer Engineering (CE)" << endl;
		cout << "2 - Computer Science (CS)" << endl;
		cout << "3 - Business Management (BM)" << endl;
		cout << "4 - Return to menu" << endl;
	    cout << "====================" << endl;
	    cout << "Enter an option: ";
	    cin >> option1;
	    
	    system("cls");
	    
		ifstream file("studentRecords.txt");
		
		string ID, pass, name, course, selectedCourse;
	    int semester, number = 1;  // Counter for line numbers
	
		switch (option1) {
			case 1:
				selectedCourse = "CE";
				
				cout << "=========================" << endl;
				cout << "COMPUTER ENGINEERING" << endl;
				cout << "=========================" << endl;
				
				while (file >> ID >> pass >>name >> course >> semester) {
					if (course == "CE") {
	            		cout << number << ". "<< ID << "\t\t" << name << endl;
	            		number++;
	        		}
	        	}
	        	break;
	        	
	        case 2:
	        	selectedCourse = "CS";
	        	
	        	cout << "=========================" << endl;
	        	cout << "COMPUTER SCIENCE" << endl;
	        	cout << "=========================" << endl;
	        	
	        	while (file >> ID >> pass >> name >> course >> semester) {
					if (course == "CS") {
	            		cout << number << ". "<< ID << "\t\t" << name << endl;
	            		number++;
	        		}
	        	}
	         	break;
	        	
	        	
	        case 3:
	        	selectedCourse = "BM";
	        	
	        	cout << "=========================" << endl;
	        	cout <<"BUSINESSES MANAGEMENT" << endl ;
				cout << "=========================" << endl;
	        	
	        	while (file >> ID >> pass >> name >> course >> semester) {
					if (course == "BM") {
	            		cout << number << ". "<< ID << "\t\t" << name << endl;
	            		number++;
	        		}
	        	}
	        	break;
	        	
	        	
	        case 4:
	        	system("cls");
				return;
				break;
	        
	        default:
				cout << "Please enter a valid option." << endl << endl;
				manageClasses();
	    }
	    
	    file.close();
		
		cout << "=========================" << endl;
		cout << "Options:" << endl;
	    cout << "1 - Add Student" << endl;
	    cout << "2 - Remove Student" << endl;
	    cout << "3 - Transfer student" << endl;
	    cout << "4 - Back" << endl;
	    cout << "=========================" << endl;
	    cout << "Enter an option: ";
	    cin >> option2;
		
	    switch (option2) {
	        case 1:
	            // Add Student Logic
	            {
		            string studentID, studentName, studentCourse, studentSemester;
		
		            cout << "Enter student ID to add: ";
		            cin >> studentID;
		            
		            cout << "Enter student name: ";
		            cin >> studentName;
		            
		            cout << "Enter student course (CE/CS/BM): ";
		            cin >> studentCourse;
		            
		            cout << "Enter student semester: ";
		            cin >> studentSemester;
		
		            ofstream recordsFile("studentRecords.txt", ios::app);
		            recordsFile << studentID << " password " << studentName << " " << studentCourse << " " << studentSemester << endl;
		            recordsFile.close();
		
					system("cls");
		
		            cout << "Student added successfully!" << endl << endl;
	        	}
	            break;
	
	        case 2:
	            // Remove Student Logic
	            {
		            string studentID;
		
		            cout << "Enter student ID to remove: ";
		            cin >> studentID;
		
		            ifstream input("studentRecords.txt");
		            ofstream temp("temp.txt");
		
		            string ID, pass, name, course, semester;
		
		            while (input >> ID >> pass >> name >> course >> semester) {
		                if (ID != studentID) {
		                    temp << ID << " " << pass << " " << name << " " << course << " " << semester << endl;
		                }
		            }
		
		            temp.close();
		            input.close();
		
		            remove("studentRecords.txt");
		            rename("temp.txt", "studentRecords.txt");
		
					system("cls");
		
		            cout << "Student removed successfully!" << endl << endl;
	        	}
	            break;
	            
	        case 3:
	        	{
	        		// Transfer student
	        		string studentID, selectedCourse;
	        		
	        		cout << "Enter student ID: ";
					cin >> studentID;
					
					cout << "Enter course (CE/CS/BM): ";
					cin >> selectedCourse;
					
					ifstream input("studentRecords.txt");
		            ofstream temp("temp.txt");
		            
		            string ID, pass, name, course, semester;
					
		        	while (input >> ID >> pass >> name >> course >> semester){
					
						if (studentID != ID){
							 temp << ID << " " << pass << " " << name << " " << course << " " << semester << endl;
					    } else{
					    	 temp << ID << " " << pass << " " << name << " " << selectedCourse << " " << semester << endl;
					    	 
						}
					}
					
					
		            temp.close();
		            input.close();
		
		            remove("studentRecords.txt");
		            rename("temp.txt", "studentRecords.txt");
		
					system("cls");
					
		            cout << "Student transfered successfully!" << endl << endl;
	        	}
	            break;
	        	
	
	        case 4:
	            system("cls");  // Clear the console 
				manageClasses();    // Call the manage classes function
				break;
	
	        default:
	            cout << "Please enter a valid option." << endl;
	    }
	}
	
}

void teacherApproval(){
	cout << "=========================" << endl;
	cout << "APPROVE REGISTRATION REQUEST" << endl;
	cout << "=========================" << endl;
	cout << "Enter BACK to go back" << endl << endl;
	
	// Open the registration requests file
    ifstream requestsFile("teacher_approval_requests.txt");
    
    // Open main records file for writing approved requests
    ofstream mainRecord("teacherRecords.txt", ios::app);

    string userID, password, name;

    while (requestsFile >> userID >> password >> name) {
        cout << "User ID: " << userID << endl;
        cout << "Name: " << name << endl;
        cout << "=========================" << endl;
        cout << "Do you want to approve this request? (YES/NO): ";

        string approval;
        cin >> approval;
        
        // Turns input uppercase
		for(int i=0;i<approval.length();i++){ 
			approval[i]=toupper(approval[i]);
		}
        

        if (approval == "YES") {
            // If approved, user is added to main record and given TEACHER role
            mainRecord << userID << " " << password << " " << name << endl;
            cout << "Request approved" << endl << endl;
        } else if (approval == "NO") {
            cout << "Request rejected" << endl << endl;
        } else if (approval == "BACK"){
        	return;
		}
    }
	
    // Close files
    requestsFile.close();
    mainRecord.close();

	// Clear teacher_approval_requests.txt
    remove("teacher_approval_requests.txt");

	system("cls");
	cout << "There are no more requests. Returning to main menu.." << endl;
	cout << "=========================" << endl << endl;
	
	return;

}


void updateRecord(string recordType){
	cout << "=========================" << endl;
	cout << "MODYIFYING RECORD.." << endl;
	cout << "=========================" << endl;
	
	int found = 0;
	string inputID, ID, password, name, course, semester;
	ifstream file;
	
	if (recordType == "STUDENT"){
		file.open("studentRecords.txt");
	} else if (recordType == "TEACHER"){
		file.open("teacherRecords.txt");
	}
	
	cout << "Enter ID or CANCEL to cancel: ";
	cin >> inputID;
	
	// Turns input uppercase
	for(int i=0; i<inputID.length(); i++){ 
		inputID[i] = toupper(inputID[i]);
	}
	
	if (inputID != "CANCEL"){

		ofstream file2("temp.txt");
		
		if (recordType == "STUDENT"){
			while (file >> ID >> password >> name >> course >> semester){
			
				if (inputID != ID){
					 file2 << ID << " " << password << " " << name << " " << course << " " << semester << endl;
			    } else{
			    	cout << "Enter ID: ";
			    	cin >> ID;
			    	cout << "Enter name:";
			    	cin >> name;
			    	
			    	for (int i=0; i<name.length(); i++){ 
						name[i]=toupper(name[i]);
					}
			    	
			    	cout << "Enter course:";
			    	cin >> course;
			    	
			    	for (int i=0; i<course.length(); i++){ 
						course[i]=toupper(course[i]);
					}
			    	
			    	 file2 << ID << " " << password << " " << name << " " << course << " " << semester << endl;
			    	 found++;
			    	 
				}
			}
		} else if (recordType == "TEACHER"){
			while (file >> ID >> password >> name){
			
				if (inputID!= ID){
					 file2 << ID << " " << password << " " << name << endl ;
			    } else {
			    	cout << "Enter ID: ";
			    	cin >> ID;
			    	cout << "Enter name:";
			    	cin >> name;
			    	
			    	for (int i=0; i<name.length(); i++){ 
						name[i]=toupper(name[i]);
					}
			    	
			    	file2 << ID << " " << password << " " << name  << endl ;
			    	found++;
			    	 
				}
			
			}
		}
		
		file.close();
		file2.close();
		
		system("cls");

        if (found == 0) {
            cout << "Record not found" << endl;
            remove("temp.txt");
        } else {
        	
        	if (recordType == "STUDENT"){
	            remove("studentRecords.txt");
	            rename("temp.txt", "studentRecords.txt");
	        }else if (recordType == "TEACHER"){
	            remove("teacherRecords.txt");
	            rename("temp.txt", "teacherRecords.txt");
        	}
        	
        	cout << "Record updated successfully" << endl;
        }	
	}			
}

void deleteRecord(string recordType){
	cout << "=========================" << endl;
	cout << "DELETING RECORD.." << endl;
	cout << "=========================" << endl;
	
	string inputID;
    int found = 0;
    string ID, password, name, course, semester;
	ifstream file;
	
	if (recordType == "STUDENT"){
		file.open("studentRecords.txt");
	} else if (recordType == "TEACHER"){
		file.open("teacherRecords.txt");
	}
	
	cout << "Enter ID or CANCEL to cancel: ";
	cin >> inputID;

    if (inputID == "CANCEL") {
        system("cls");
        return;
        
    } else {
        ofstream tempFile("temp.txt");

		if (recordType == "STUDENT"){
		
	        while (file >> ID >> password >> name >> course >> semester) {
	            if (inputID != ID) {
	                tempFile << ID << " " << password << " " << name << " " << course << " " << semester << endl;
	            } else {
	                found++;
	            }
	        }
    	} else if (recordType == "TEACHER"){
    		 while (file >> ID >> password >> name) {
	            if (inputID != ID) {
	                tempFile << ID << " " << password << " " << name << endl;
	            } else {
	                found++;
	            }
	        }
    		
		}

        file.close();
        tempFile.close();

        if (found == 0) {
            cout << "Record not found" << endl;
            remove("temp.txt");
        } else {
        	
        	if (recordType == "STUDENT"){
	            remove("studentRecords.txt");
	            rename("temp.txt", "studentRecords.txt");
	        }else if (recordType == "TEACHER"){
	            remove("teacherRecords.txt");
	            rename("temp.txt", "teacherRecords.txt");
        	}
        	
        	cout << "Record deleted successfully" << endl;
        }
    }
    return;
    
}


void searchRecord(string recordType){
	system("cls");
	cout << "=========================" << endl;
	cout << "SEARCHING RECORDS.." << endl;
	cout << "=========================" << endl;
	
	string inputID;
    int found = 0;
    string ID, password, name, course, semester;
    ifstream file;

    if (recordType == "STUDENT"){
		file.open("studentRecords.txt");
	} else if (recordType == "TEACHER"){
		file.open("teacherRecords.txt");
	}
    
	cout << "Enter ID or CANCEL to cancel: ";
	cin >> inputID;
	
	// Turns input uppercase
	for(int i=0;i<inputID.length();i++){ 
		inputID[i]=toupper(inputID[i]);
	}
	
	system("cls");
	
	if (inputID != "CANCEL"){
		if (recordType == "STUDENT"){
			while(file >> ID >> password >> name >> course >> semester){
			
				if (inputID == ID){
					found = 1;
					cout << "=========================" << endl;
					cout << "RECORD FOUND" <<endl;
					cout << "=========================" << endl;
									
			    	cout << "User ID: " << ID << endl;
					cout << "Name: "<< name << endl;
					cout << "Course: " << course << endl;
					cout << "Current semester: " << semester << endl;
					cout << "=========================" << endl;
				}
			}
		} else if (recordType == "TEACHER"){
			while(file >> ID >> password >> name){
			
				if (inputID == ID){
					found = 1;
					cout << "=========================" << endl;
					cout << "RECORD FOUND" <<endl;
					cout << "=========================" << endl;
									
			    	cout << "User ID: " << ID << endl;
					cout << "Name: "<< name << endl;
					cout << "=========================" << endl;
				}
			}
		}
		
	
		if (found == 0){
			cout << "=========================" << endl;
			cout << "RECORD NOT FOUND" << endl;
			cout << "=========================" << endl;
		}
		
		system("pause");
	}
	
	file.close();
	system("cls");
	return;
	
}
