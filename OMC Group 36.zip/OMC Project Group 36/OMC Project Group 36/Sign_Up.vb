﻿Imports System.Data.OleDb
Imports System.Text.RegularExpressions


Public Class Sign_Up

    Dim conn As New OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" & Application.StartupPath & "\DeliverUS_Database.accdb")
    Dim cmd As OleDbCommand
    Dim dt As New DataTable
    Dim da As New OleDbDataAdapter(cmd)
    Dim dr As OleDbDataReader


    ' Function to check the format of E-mail:
    Function checkEmail()
        Dim emailValid As Boolean
        Dim emailAddressMatch As Match = Regex.Match(txtEmail.Text, "^([\w-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([\w-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$")

        If emailAddressMatch.Success Then
            emailValid = True
            lblWrongEmail.Hide()
        Else
            emailValid = False
            lblWrongEmail.Show()
        End If

        Return emailValid
    End Function


    Private Sub txtEmail_Leave(sender As Object, e As EventArgs) Handles txtEmail.Leave
        checkEmail()
    End Sub


    Private Sub txtPassword_TextChanged(sender As Object, e As EventArgs) Handles txtPassword.TextChanged
        lblMismatchedPassword.Hide()
    End Sub


    Private Sub txtConfirmPassword_TextChanged(sender As Object, e As EventArgs) Handles txtConfirmPassword.TextChanged
        lblMismatchedPassword.Hide()
    End Sub


    Private Sub btnSignUp_Click(sender As Object, e As EventArgs) Handles btnSignUp.Click
        Dim passwordCheck As Boolean = True
        Dim emailCheck As Boolean = True
        Dim i As New Integer

        'Check if email is correctly formated (eg xxx@xxx.xxx)
        checkEmail()

        'Check if passwords in both textboxes match
        If txtPassword.Text <> txtConfirmPassword.Text Then
            lblMismatchedPassword.Show()
            passwordCheck = False
        Else
            passwordCheck = True
        End If

        ' First check if all fields are filled in
        If txtStudentID.Text = "" Or txtEmail.Text = "" Or txtPassword.Text = "" Or txtConfirmPassword.Text = "" Then
            MsgBox("Fill in details")
        Else

            ' Verify that email is correctly formated & Passwords match
            If emailCheck = True And passwordCheck = True Then

                conn.Open()
                    Dim cmd As New OleDbCommand("insert into UserData(`StudentID`,`Email`,`Password`) values (@StudentID,@Email,@Password)", conn)

                    cmd.Parameters.Clear()
                    cmd.Parameters.AddWithValue("@StudentID", txtStudentID.Text)
                    cmd.Parameters.AddWithValue("@Email", txtEmail.Text)
                    cmd.Parameters.AddWithValue("@Password", txtPassword.Text)

                If cmd.ExecuteNonQuery > 0 Then

                    MsgBox("Sign Up successful!", vbInformation)

                    StudentID = txtStudentID.Text

                    CUSTOMER_Main_Menu.Show()


                    Me.Close()

                    txtStudentID.Clear()
                    txtEmail.Clear()
                    txtPassword.Clear()
                    txtConfirmPassword.Clear()

                Else
                    MsgBox("Sign Up failed. Try again.", vbCritical)
                End If

                conn.Close()


            Else
                MsgBox("Sign Up failed. Try again", vbCritical)

            End If

        End If



    End Sub

    Private Sub btnCancel_Click(sender As Object, e As EventArgs) Handles btnCancel.Click
        Me.Dispose()
        Me.Hide()
        Starting_Menu.Show()
    End Sub


End Class