﻿Imports System.Data.OleDb

Public Class ADMIN_Customer_Form
    Sub FormUpdate()
        txtName.Text = ADMIN_Customer_List.grdCustomerList.CurrentRow.Cells(1).Value.ToString
        txtGender.Text = ADMIN_Customer_List.grdCustomerList.CurrentRow.Cells(4).Value.ToString
        txtPhone.Text = ADMIN_Customer_List.grdCustomerList.CurrentRow.Cells(3).Value.ToString
        txtStudentID.Text = ADMIN_Customer_List.grdCustomerList.CurrentRow.Cells(0).Value.ToString
        txtEmail.Text = ADMIN_Customer_List.grdCustomerList.CurrentRow.Cells(2).Value.ToString
        txtVillage.Text = ADMIN_Customer_List.grdCustomerList.CurrentRow.Cells(5).Value.ToString
        txtBlock.Text = ADMIN_Customer_List.grdCustomerList.CurrentRow.Cells(6).Value.ToString
        txtFloor.Text = ADMIN_Customer_List.grdCustomerList.CurrentRow.Cells(7).Value.ToString
        txtRoom.Text = ADMIN_Customer_List.grdCustomerList.CurrentRow.Cells(8).Value.ToString

    End Sub

    Private Sub btnPrev_Click(sender As Object, e As EventArgs) Handles btnPrev.Click
        ADMIN_Customer_List.UserDataBindingSource.MovePrevious()
        FormUpdate()
    End Sub

    Private Sub btnNext_Click(sender As Object, e As EventArgs) Handles btnNext.Click
        ADMIN_Customer_List.UserDataBindingSource.MoveNext()
        FormUpdate()
    End Sub

End Class