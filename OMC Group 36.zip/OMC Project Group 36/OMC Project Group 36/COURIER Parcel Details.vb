﻿Imports System.Data.OleDb

Public Class COURIER_Parcel_Details

    Dim conn As New OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" & Application.StartupPath & "\DeliverUS_Database.accdb")
    Dim cmd As OleDbCommand
    Dim dt As New DataTable
    Dim da As New OleDbDataAdapter(cmd)
    Dim dr As OleDbDataReader

    Dim TrackingNumber As String = COURIER_Check_Parcels.TrackingNumber

    Public Sub btnDeliverParcel_Click(sender As Object, e As EventArgs) Handles btnDeliverParcel.Click
        Dim result As Integer
        result = MsgBox("Are you sure?", vbYesNo + vbQuestion, "Confirm delivery")

        If result = vbYes Then
            conn.Open()
            Dim cmd As New OleDbCommand("UPDATE ParcelData SET CourierID=@CourierID,DeliveryStatus=@DeliveryStatus  WHERE TrackingNumber=@TrackingNumber", conn)

            cmd.Parameters.Clear()
            cmd.Parameters.AddWithValue("@CourierID", StudentID)
            cmd.Parameters.AddWithValue("@DeliveryStatus", "Delivering")
            cmd.Parameters.AddWithValue("@TrackingNumber", TrackingNumber)


            conn.Close()
            Me.Close()
        End If
    End Sub

    Private Sub COURIER_Parcel_Details_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Dim dr, dr2 As OleDbDataReader
        Dim CustomerID As String

        conn.Open()
        Dim cmd As New OleDbCommand("Select CustomerID from ParcelData where TrackingNumber=@TrackingNumber", conn)

        cmd.Parameters.AddWithValue("@TrackingNumber", TrackingNumber)


        dr = cmd.ExecuteReader

        If dr.Read() Then
            CustomerId = dr("CustomerID").ToString

        End If


        Dim cmd2 As New OleDbCommand("Select *  from UserData where StudentID=@StudentID", conn)

        cmd2.Parameters.Clear()
        cmd2.Parameters.AddWithValue("@StudentID", CustomerID)


        dr2 = cmd2.ExecuteReader

        If dr2.Read() Then
            txtAddress.Text = "V" & dr2("Village").ToString & dr2("Block").ToString & "-" & dr2("Floor").ToString & "-" & dr2("Room").ToString & "-" & dr2("Room").ToString
        End If

        conn.Close()
    End Sub

    Private Sub btnCancel_Click(sender As Object, e As EventArgs) Handles btnCancel.Click
        Me.Close()
    End Sub
End Class