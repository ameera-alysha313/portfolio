﻿Public Class COURIER_Delivery_Status
    Private Sub COURIER_Delivery_Status_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'DeliverUS_DatabaseDataSet5.ParcelData' table. You can move, or remove it, as needed.
        Me.ParcelDataTableAdapter5.Fill(Me.DeliverUS_DatabaseDataSet5.ParcelData)


        ParcelDataBindingSource2.Filter = $"CourierID LIKE '{StudentID}%'"

    End Sub

    Private Sub btnBack_Click(sender As Object, e As EventArgs) Handles btnBack.Click
        Me.Close()
        COURIER_Main_Menu.Show()
    End Sub

    Private Sub COURIER_Delivery_Status_FormClosed(sender As Object, e As FormClosedEventArgs) Handles MyBase.FormClosed
        COURIER_Main_Menu.Show()
    End Sub

    Private Sub grdCourierList_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles grdCourierList.CellContentClick

    End Sub
End Class