﻿Imports System.Data.OleDb
Imports System.Diagnostics.Contracts
Imports System.Security.Cryptography

Friend Module GlobalVariable
    Public StudentID As String

End Module


Public Class Login

    Dim conn As New OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" & Application.StartupPath & "\DeliverUS_Database.accdb")
    Dim cmd As OleDbCommand
    Dim dt As New DataTable
    Dim da As New OleDbDataAdapter(cmd)
    Dim dr As OleDbDataReader


    Private Sub chkShowPassword_CheckedChanged(sender As Object, e As EventArgs) Handles chkShowPassword.CheckedChanged

        If chkShowPassword.Checked = True Then
            txtPassword.UseSystemPasswordChar = False

        Else
            txtPassword.UseSystemPasswordChar = True
        End If
    End Sub

    Private Sub btnBack_Click(sender As Object, e As EventArgs) Handles btnBack.Click
        Me.Dispose()
        Me.Hide()
        Starting_Menu.Show()
    End Sub


    Public Sub btnLogIn_Click(sender As Object, e As EventArgs) Handles btnLogIn.Click
        Try
            conn.Open()
            Dim cmd As New OleDbCommand("select*from UserData where StudentID=@StudentID AND Password=@Password", conn)
            cmd.Parameters.Clear()
            cmd.Parameters.AddWithValue("@StudentID", txtStudentID.Text)
            cmd.Parameters.AddWithValue("@Password", txtPassword.Text)

            Dim StudentID As String = ""
            Dim Password As String = ""

            dr = cmd.ExecuteReader

            If (dr.Read() = True) Then
                StudentID = dr("StudentID")
                Password = dr("Password")

                GlobalVariable.StudentID = StudentID

                CUSTOMER_Main_Menu.Show()
                Me.Close()

            Else
                MsgBox("Invalid Student ID or password. Try again.", vbOKOnly + vbCritical, "Invalid credentials")
            End If

        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
        conn.Close()
    End Sub

End Class
