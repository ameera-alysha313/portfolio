﻿Imports System.Data.OleDb

Public Class ADMIN_Customer_List

    Dim conn As New OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" & Application.StartupPath & "\DeliverUS_Database.accdb")
    Dim cmd As OleDbCommand
    Dim dt As New DataTable
    Dim da As New OleDbDataAdapter(cmd)

    Private Sub ADMIN_Customer_List_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'DeliverUS_DatabaseDataSet2.UserData' table. You can move, or remove it, as needed.
        Me.UserDataTableAdapter2.Fill(Me.DeliverUS_DatabaseDataSet2.UserData)


    End Sub

    Private Sub grdCustomerList_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles grdCustomerList.CellContentClick

        'Opens a window that displays the information
        ADMIN_Customer_Form.Show()

        ADMIN_Customer_Form.txtName.Text = grdCustomerList.CurrentRow.Cells(1).Value.ToString
        ADMIN_Customer_Form.txtGender.Text = grdCustomerList.CurrentRow.Cells(4).Value.ToString
        ADMIN_Customer_Form.txtPhone.Text = grdCustomerList.CurrentRow.Cells(3).Value.ToString
        ADMIN_Customer_Form.txtStudentID.Text = grdCustomerList.CurrentRow.Cells(0).Value.ToString
        ADMIN_Customer_Form.txtEmail.Text = grdCustomerList.CurrentRow.Cells(2).Value.ToString
        ADMIN_Customer_Form.txtVillage.Text = grdCustomerList.CurrentRow.Cells(5).Value.ToString
        ADMIN_Customer_Form.txtBlock.Text = grdCustomerList.CurrentRow.Cells(6).Value.ToString
        ADMIN_Customer_Form.txtFloor.Text = grdCustomerList.CurrentRow.Cells(7).Value.ToString
        ADMIN_Customer_Form.txtRoom.Text = grdCustomerList.CurrentRow.Cells(8).Value.ToString

    End Sub

    Private Sub txtSearch_Enter(sender As Object, e As EventArgs) Handles txtSearch.Enter

        'Auto fill for search box

        Dim dr As OleDbDataReader
        Dim ds As New DataSet
        Dim searchBy As String


        If cbSearchBy.Text = "Student ID" Then
            searchBy = "StudentID"

        ElseIf cbSearchBy.Text = "E-mail" Then
            searchBy = "Email"

        ElseIf cbSearchBy.Text = "Name" Then
            searchBy = "FullName"

        ElseIf cbSearchBy.Text = "Phone" Then
            searchBy = "Phone"

        End If

        Dim cmd As New OleDbCommand("Select " & searchBy & " from UserData Order By StudentID ASC", conn)
        Dim autoComp As New AutoCompleteStringCollection()

        conn.Open()

        dr = cmd.ExecuteReader

        While dr.Read()
            autoComp.Add(dr(searchBy))
        End While

        txtSearch.AutoCompleteMode = AutoCompleteMode.Suggest
        txtSearch.AutoCompleteSource = AutoCompleteSource.CustomSource
        txtSearch.AutoCompleteCustomSource = autoComp

        conn.Close()

    End Sub

    Private Sub btnSearch_Click(sender As Object, e As EventArgs) Handles btnSearch.Click
        Dim temp As Integer = 0
        Dim colIndex As Integer

        grdCustomerList.CurrentRow.Selected = False

        If cbSearchBy.Text = "Student ID" Then
            colIndex = 0

        ElseIf cbSearchBy.Text = "E-mail" Then
            colIndex = 2

        ElseIf cbSearchBy.Text = "Name" Then
            colIndex = 1

        ElseIf cbSearchBy.Text = "Phone" Then
            colIndex = 3

        End If

        For i As Integer = 0 To grdCustomerList.RowCount - 1

            If grdCustomerList.Rows(i).Cells(colIndex).Value.ToString = txtSearch.Text Then
                grdCustomerList.Rows(i).Selected = True
                MsgBox("User found")
                temp = 1
            End If

        Next

        If temp = 0 Then
            MsgBox("User not found")
        End If

    End Sub
    Private Sub btnBack_Click(sender As Object, e As EventArgs) Handles btnBack.Click
        Me.Close()
        ADMIN_Main_Menu.Show()
    End Sub

End Class