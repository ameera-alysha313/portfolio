﻿Imports System.Data.OleDb

Public Class CUSTOMER_Main_Menu

    Dim conn As New OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" & Application.StartupPath & "\DeliverUS_Database.accdb")
    Dim cmd As OleDbCommand
    Dim dt As New DataTable
    Dim da As New OleDbDataAdapter(cmd)


    Public Sub CUSTOMER_Main_Menu_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        Dim dr, dr2 As OleDbDataReader

        ' If user is a courier they can press a button to switch to courier menu
        conn.Open()
        Dim cmd As New OleDbCommand("select* from CourierData where StudentID=@StudentID", conn)
        cmd.Parameters.Clear()
        cmd.Parameters.AddWithValue("@StudentID", StudentID)

        dr = cmd.ExecuteReader

        If dr.Read() = True Then
            btnCourierMenu.Show()
        End If

        ' If user is also an admin they can press a button to switch to admin menu
        Dim cmd2 As New OleDbCommand("select * from AdminData where StudentID=@StudentID", conn)
        cmd2.Parameters.Clear()
        cmd2.Parameters.AddWithValue("@StudentID", StudentID)

        dr2 = cmd2.ExecuteReader

        If dr2.Read() = True Then
            btnAdminMenu.Show()
        End If

        conn.Close()

    End Sub



    Private Sub btnUserProfile_Click(sender As Object, e As EventArgs) Handles btnUserProfile.Click
        CUSTOMER_User_Profile.Show()
        Me.Hide()
    End Sub


    Private Sub btnCheckParcel_Click(sender As Object, e As EventArgs) Handles btnCheckParcel.Click
        CUSTOMER_Parcel_Status.Show()
        Me.Hide()
    End Sub

    Private Sub btnAdminMenu_Click(sender As Object, e As EventArgs) Handles btnAdminMenu.Click
        Me.Hide()
        ADMIN_Main_Menu.Show()
    End Sub

    Private Sub btnCourierMenu_Click(sender As Object, e As EventArgs) Handles btnCourierMenu.Click
        Me.Hide()
        COURIER_Main_Menu.Show()
    End Sub

    Private Sub btnLogOut_Click(sender As Object, e As EventArgs) Handles btnLogOut.Click
        Dim result As Integer
        result = MsgBox("Are you sure you want to log out?", vbYesNo + vbExclamation, "Logging out..")

        If result = vbYes Then
            StudentID = ""
        End If

        Me.Close()
        Starting_Menu.Show()
    End Sub

    Private Sub btnExit_Click_1(sender As Object, e As EventArgs) Handles btnExit.Click
        Dim result As Integer
        result = MsgBox("Are you sure you want to exit the application?", vbYesNo + vbExclamation, "Exiting Aplication")

        If result = vbYes Then
            Application.Exit()
        End If
    End Sub


End Class