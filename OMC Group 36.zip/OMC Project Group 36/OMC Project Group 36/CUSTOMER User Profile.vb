﻿Imports System.Data.OleDb

Public Class CUSTOMER_User_Profile

    Dim conn As New OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" & Application.StartupPath & "\DeliverUS_Database.accdb")
    Dim cmd As OleDbCommand
    Dim dt As New DataTable
    Dim da As New OleDbDataAdapter(cmd)
    Private bitmap As Bitmap

    Public Sub User_Profile_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Dim dr As OleDbDataReader

        conn.Open()
        Dim cmd As New OleDbCommand("Select * from UserData where StudentID=@StudentID", conn)


        cmd.Parameters.Clear()
        cmd.Parameters.AddWithValue("@StudentID", StudentID)


        dr = cmd.ExecuteReader

        If dr.Read() Then
            txtStudentID.Text = dr("StudentID").ToString
            txtEmail.Text = dr("Email").ToString
            txtName.Text = dr("FullName").ToString
            txtPhone.Text = dr("Phone").ToString
            cboGender.Text = dr("Gender").ToString
            txtVillage.Text = dr("Village").ToString
            txtBlock.Text = dr("Block").ToString
            txtFloor.Text = dr("Floor").ToString
            txtRoom.Text = dr("Room").ToString

        End If

        conn.Close()
    End Sub

    Private Sub btnSave_Click(sender As Object, e As EventArgs) Handles btnSave.Click


        Dim result As Integer
        result = MsgBox("Are you sure you want to save these changes?", vbYesNo + vbQuestion, "Saving Changes")

        If result = vbYes Then

            Try
                conn.Open()
                Dim cmd As New OleDbCommand("UPDATE UserData SET Email=@Email,FullName=@Fullname,Phone=@Phone,Gender=@Gender,Village=@Village,Block=@Block,Floor=@Floor,Room=@Room WHERE StudentID=@StudentID", conn)
                cmd.Parameters.Clear()
                cmd.Parameters.AddWithValue("@StudentID", StudentID)
                cmd.Parameters.AddWithValue("@Email", txtEmail.Text)
                cmd.Parameters.AddWithValue("@Fullname", txtName.Text)
                cmd.Parameters.AddWithValue("@Phone", txtPhone.Text)
                cmd.Parameters.AddWithValue("@Gender", cboGender.Text)
                cmd.Parameters.AddWithValue("@Village", txtVillage.Text)
                cmd.Parameters.AddWithValue("@Block", txtBlock.Text)
                cmd.Parameters.AddWithValue("@Floor", txtFloor.Text)
                cmd.Parameters.AddWithValue("@Room", txtRoom.Text)

                MsgBox("Profile update successful!")

                cmd.Dispose()
                conn.Close()

            Catch ex As Exception
                MsgBox(ex.Message)
            End Try
        End If

    End Sub

    Private Sub btnRegisterCourier_Click(sender As Object, e As EventArgs)
        CUSTOMER_Courier_Registration.Show()
    End Sub

    Private Sub CUSTOMER_User_Profile_FormClosed(sender As Object, e As FormClosedEventArgs) Handles MyBase.FormClosed
        CUSTOMER_Main_Menu.Show()
    End Sub

    Private Sub btnBack_Click(sender As Object, e As EventArgs) Handles btnBack.Click
        Me.Close()
        CUSTOMER_Main_Menu.Show()
    End Sub

End Class