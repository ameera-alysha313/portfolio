﻿Imports System.Data.OleDb

Public Class COURIER_User_Profile
    Dim conn As New OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" & Application.StartupPath & "\DeliverUS_Database.accdb")
    Dim cmd As OleDbCommand
    Dim constr As String
    Dim dt As New DataTable
    Dim da As New OleDbDataAdapter(cmd)

    Public Sub COURIER_User_Profile_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Dim dr As OleDbDataReader
        Dim picture() As Byte

        conn.Open()
        Dim cmd As New OleDbCommand("Select*from CourierData where StudentID=@StudentID", conn)
        cmd.Parameters.Clear()
        cmd.Parameters.AddWithValue("@StudentID", StudentID)


        dr = cmd.ExecuteReader

        If dr.Read() Then
            txtStudentID.Text = dr("StudentID").ToString
            txtEmail.Text = dr("Email").ToString
            txtName.Text = dr("FullName").ToString
            txtPhone.Text = dr("Phone").ToString
            cboGender.Text = dr("Gender").ToString

        End If

        conn.Close()
    End Sub


    Private Sub btnSave_Click(sender As Object, e As EventArgs) Handles btnSave.Click
        Dim result As Integer
        result = MsgBox("Are you sure you want to save these changes?", vbYesNo + vbQuestion, "Saving Changes")

        If result = vbYes Then

            conn.Open()
            Dim cmd As New OleDbCommand("UPDATE CourierData SET Email=@Email, FullName=@FullName, Phone=@Phone, Gender=@Gender WHERE StudentID=@StudentID", conn)
            cmd.Parameters.AddWithValue("@StudentID", StudentID)
            cmd.Parameters.AddWithValue("@Email", txtEmail.Text)
            cmd.Parameters.AddWithValue("@FullName", txtName.Text)
            cmd.Parameters.AddWithValue("@Phone", txtPhone.Text)
            cmd.Parameters.AddWithValue("@Gender", cboGender.Text)

            MsgBox("Profile update successful!")

            conn.Close()

        End If

    End Sub

    Private Sub btnBack_Click(sender As Object, e As EventArgs) Handles btnBack.Click
        Me.Dispose()
        Me.Hide()
        COURIER_Main_Menu.Show()
    End Sub

End Class