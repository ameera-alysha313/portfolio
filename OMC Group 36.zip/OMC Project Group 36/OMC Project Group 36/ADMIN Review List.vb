﻿Imports System.Data.OleDb

Public Class ADMIN_Review_List
    Dim conn As New OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" & Application.StartupPath & "\DeliverUS_Database.accdb")
    Dim cmd As OleDbCommand
    Dim dt As New DataTable
    Dim da As New OleDbDataAdapter(cmd)

    Public starRating As String

    Private Sub ADMIN_Review_List_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'DeliverUS_DatabaseDataSet.ReviewData' table. You can move, or remove it, as needed.
        Me.ReviewDataTableAdapter.Fill(Me.DeliverUS_DatabaseDataSet.ReviewData)

    End Sub

    Private Sub btnBack_Click(sender As Object, e As EventArgs) Handles btnBack.Click
        Me.Close()
        ADMIN_Main_Menu.Show()
    End Sub

    Private Sub grdReviewList_CellContentClick_1(sender As Object, e As DataGridViewCellEventArgs) Handles grdReviewList.CellContentClick

        ADMIN_Review_Form.Show()

        ADMIN_Review_Form.txtReview.Text = grdReviewList.CurrentRow.Cells(5).Value.ToString
        Me.starRating = grdReviewList.CurrentRow.Cells(4).Value.ToString
    End Sub
End Class