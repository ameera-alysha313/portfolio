﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Payment_Method
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.btnNext = New System.Windows.Forms.Button()
        Me.btnCancel = New System.Windows.Forms.Button()
        Me.pnlCOD = New System.Windows.Forms.Panel()
        Me.lblCOD = New System.Windows.Forms.Label()
        Me.chkCOD = New System.Windows.Forms.CheckBox()
        Me.pbCOD = New System.Windows.Forms.PictureBox()
        Me.pnlVisa = New System.Windows.Forms.Panel()
        Me.lblVisa = New System.Windows.Forms.Label()
        Me.chkVisa = New System.Windows.Forms.CheckBox()
        Me.pbVisa = New System.Windows.Forms.PictureBox()
        Me.pnlOnlineBanking = New System.Windows.Forms.Panel()
        Me.lblOnlineBanking = New System.Windows.Forms.Label()
        Me.chkOnlineBanking = New System.Windows.Forms.CheckBox()
        Me.pbOnlineBanking = New System.Windows.Forms.PictureBox()
        Me.pnlCOD.SuspendLayout()
        CType(Me.pbCOD, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.pnlVisa.SuspendLayout()
        CType(Me.pbVisa, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.pnlOnlineBanking.SuspendLayout()
        CType(Me.pbOnlineBanking, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 18.0!)
        Me.Label1.Location = New System.Drawing.Point(269, 188)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(393, 40)
        Me.Label1.TabIndex = 12
        Me.Label1.Text = "Pick a payment method"
        '
        'btnNext
        '
        Me.btnNext.Location = New System.Drawing.Point(708, 781)
        Me.btnNext.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.btnNext.Name = "btnNext"
        Me.btnNext.Size = New System.Drawing.Size(143, 55)
        Me.btnNext.TabIndex = 11
        Me.btnNext.Text = "Next"
        Me.btnNext.UseVisualStyleBackColor = True
        '
        'btnCancel
        '
        Me.btnCancel.Location = New System.Drawing.Point(108, 781)
        Me.btnCancel.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.btnCancel.Name = "btnCancel"
        Me.btnCancel.Size = New System.Drawing.Size(143, 55)
        Me.btnCancel.TabIndex = 10
        Me.btnCancel.Text = "Cancel"
        Me.btnCancel.UseVisualStyleBackColor = True
        '
        'pnlCOD
        '
        Me.pnlCOD.Controls.Add(Me.lblCOD)
        Me.pnlCOD.Controls.Add(Me.chkCOD)
        Me.pnlCOD.Controls.Add(Me.pbCOD)
        Me.pnlCOD.Location = New System.Drawing.Point(232, 594)
        Me.pnlCOD.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.pnlCOD.Name = "pnlCOD"
        Me.pnlCOD.Size = New System.Drawing.Size(488, 110)
        Me.pnlCOD.TabIndex = 9
        '
        'lblCOD
        '
        Me.lblCOD.AutoSize = True
        Me.lblCOD.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!)
        Me.lblCOD.Location = New System.Drawing.Point(360, 32)
        Me.lblCOD.Name = "lblCOD"
        Me.lblCOD.Size = New System.Drawing.Size(91, 50)
        Me.lblCOD.TabIndex = 4
        Me.lblCOD.Text = "Cash On" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Delivery"
        Me.lblCOD.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'chkCOD
        '
        Me.chkCOD.AutoSize = True
        Me.chkCOD.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.chkCOD.Location = New System.Drawing.Point(21, 46)
        Me.chkCOD.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.chkCOD.Name = "chkCOD"
        Me.chkCOD.Size = New System.Drawing.Size(22, 21)
        Me.chkCOD.TabIndex = 1
        Me.chkCOD.UseVisualStyleBackColor = True
        '
        'pbCOD
        '
        Me.pbCOD.Image = Global.OMC_Project_Group_36.My.Resources.Resources.COD_Icon
        Me.pbCOD.Location = New System.Drawing.Point(70, 2)
        Me.pbCOD.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.pbCOD.Name = "pbCOD"
        Me.pbCOD.Size = New System.Drawing.Size(253, 105)
        Me.pbCOD.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.pbCOD.TabIndex = 0
        Me.pbCOD.TabStop = False
        '
        'pnlVisa
        '
        Me.pnlVisa.Controls.Add(Me.lblVisa)
        Me.pnlVisa.Controls.Add(Me.chkVisa)
        Me.pnlVisa.Controls.Add(Me.pbVisa)
        Me.pnlVisa.Location = New System.Drawing.Point(232, 416)
        Me.pnlVisa.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.pnlVisa.Name = "pnlVisa"
        Me.pnlVisa.Size = New System.Drawing.Size(488, 110)
        Me.pnlVisa.TabIndex = 8
        '
        'lblVisa
        '
        Me.lblVisa.AutoSize = True
        Me.lblVisa.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!)
        Me.lblVisa.Location = New System.Drawing.Point(379, 46)
        Me.lblVisa.Name = "lblVisa"
        Me.lblVisa.Size = New System.Drawing.Size(51, 25)
        Me.lblVisa.TabIndex = 3
        Me.lblVisa.Text = "Visa"
        '
        'chkVisa
        '
        Me.chkVisa.AutoSize = True
        Me.chkVisa.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.chkVisa.Location = New System.Drawing.Point(21, 46)
        Me.chkVisa.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.chkVisa.Name = "chkVisa"
        Me.chkVisa.Size = New System.Drawing.Size(22, 21)
        Me.chkVisa.TabIndex = 1
        Me.chkVisa.UseVisualStyleBackColor = True
        '
        'pbVisa
        '
        Me.pbVisa.Image = Global.OMC_Project_Group_36.My.Resources.Resources.visa_and_mastercard_logo_26
        Me.pbVisa.Location = New System.Drawing.Point(87, 2)
        Me.pbVisa.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.pbVisa.Name = "pbVisa"
        Me.pbVisa.Size = New System.Drawing.Size(236, 105)
        Me.pbVisa.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.pbVisa.TabIndex = 0
        Me.pbVisa.TabStop = False
        '
        'pnlOnlineBanking
        '
        Me.pnlOnlineBanking.Controls.Add(Me.lblOnlineBanking)
        Me.pnlOnlineBanking.Controls.Add(Me.chkOnlineBanking)
        Me.pnlOnlineBanking.Controls.Add(Me.pbOnlineBanking)
        Me.pnlOnlineBanking.Location = New System.Drawing.Point(232, 258)
        Me.pnlOnlineBanking.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.pnlOnlineBanking.Name = "pnlOnlineBanking"
        Me.pnlOnlineBanking.Size = New System.Drawing.Size(488, 110)
        Me.pnlOnlineBanking.TabIndex = 7
        '
        'lblOnlineBanking
        '
        Me.lblOnlineBanking.AutoSize = True
        Me.lblOnlineBanking.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblOnlineBanking.Location = New System.Drawing.Point(368, 29)
        Me.lblOnlineBanking.Name = "lblOnlineBanking"
        Me.lblOnlineBanking.Size = New System.Drawing.Size(83, 50)
        Me.lblOnlineBanking.TabIndex = 2
        Me.lblOnlineBanking.Text = "Online" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Banking"
        Me.lblOnlineBanking.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'chkOnlineBanking
        '
        Me.chkOnlineBanking.AutoSize = True
        Me.chkOnlineBanking.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.chkOnlineBanking.Location = New System.Drawing.Point(21, 46)
        Me.chkOnlineBanking.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.chkOnlineBanking.Name = "chkOnlineBanking"
        Me.chkOnlineBanking.Size = New System.Drawing.Size(22, 21)
        Me.chkOnlineBanking.TabIndex = 1
        Me.chkOnlineBanking.UseVisualStyleBackColor = True
        '
        'pbOnlineBanking
        '
        Me.pbOnlineBanking.Image = Global.OMC_Project_Group_36.My.Resources.Resources.fpx_logo_vector_01
        Me.pbOnlineBanking.Location = New System.Drawing.Point(87, 9)
        Me.pbOnlineBanking.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.pbOnlineBanking.Name = "pbOnlineBanking"
        Me.pbOnlineBanking.Size = New System.Drawing.Size(236, 90)
        Me.pbOnlineBanking.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.pbOnlineBanking.TabIndex = 0
        Me.pbOnlineBanking.TabStop = False
        '
        'Payment_Method
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(9.0!, 20.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1009, 1002)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.btnNext)
        Me.Controls.Add(Me.btnCancel)
        Me.Controls.Add(Me.pnlCOD)
        Me.Controls.Add(Me.pnlVisa)
        Me.Controls.Add(Me.pnlOnlineBanking)
        Me.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.Name = "Payment_Method"
        Me.Text = "Payment Method"
        Me.pnlCOD.ResumeLayout(False)
        Me.pnlCOD.PerformLayout()
        CType(Me.pbCOD, System.ComponentModel.ISupportInitialize).EndInit()
        Me.pnlVisa.ResumeLayout(False)
        Me.pnlVisa.PerformLayout()
        CType(Me.pbVisa, System.ComponentModel.ISupportInitialize).EndInit()
        Me.pnlOnlineBanking.ResumeLayout(False)
        Me.pnlOnlineBanking.PerformLayout()
        CType(Me.pbOnlineBanking, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Label1 As Label
    Friend WithEvents btnNext As Button
    Friend WithEvents btnCancel As Button
    Friend WithEvents pnlCOD As Panel
    Friend WithEvents lblCOD As Label
    Friend WithEvents chkCOD As CheckBox
    Friend WithEvents pbCOD As PictureBox
    Friend WithEvents pnlVisa As Panel
    Friend WithEvents lblVisa As Label
    Friend WithEvents chkVisa As CheckBox
    Friend WithEvents pbVisa As PictureBox
    Friend WithEvents pnlOnlineBanking As Panel
    Friend WithEvents lblOnlineBanking As Label
    Friend WithEvents chkOnlineBanking As CheckBox
    Friend WithEvents pbOnlineBanking As PictureBox
End Class
