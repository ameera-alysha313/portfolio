﻿Public Class CUSTOMER_Method_Of_Payment
    Private Sub btnNext_Click(sender As Object, e As EventArgs) Handles btnNext.Click
        If rbCOD.Checked = True Then
            Dim result As Integer
            result = MsgBox("By choosing Cash on Delivery you are agreeing to pay for your parcel to the courier directly when they deliver your parcel", vbOKCancel, "Cash On Delivery")

            If result = vbOK Then
                Me.Close()
            End If


        Else

            CUSTOMER_QR_Pay.Show()
            Me.Hide()
        End If
    End Sub

    Private Sub btnBack_Click(sender As Object, e As EventArgs) Handles btnBack.Click

    End Sub
End Class