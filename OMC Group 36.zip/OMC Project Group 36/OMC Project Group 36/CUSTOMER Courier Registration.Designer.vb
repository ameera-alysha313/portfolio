﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class CUSTOMER_Courier_Registration
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(CUSTOMER_Courier_Registration))
        Me.lblINstructions = New System.Windows.Forms.Label()
        Me.btnUploadID = New System.Windows.Forms.Button()
        Me.UploadLicense = New System.Windows.Forms.Button()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.btnRegister = New System.Windows.Forms.Button()
        Me.picLicense = New System.Windows.Forms.PictureBox()
        Me.picStudentCard = New System.Windows.Forms.PictureBox()
        CType(Me.picLicense, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picStudentCard, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'lblINstructions
        '
        Me.lblINstructions.AutoSize = True
        Me.lblINstructions.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblINstructions.ForeColor = System.Drawing.Color.White
        Me.lblINstructions.Location = New System.Drawing.Point(50, 81)
        Me.lblINstructions.Name = "lblINstructions"
        Me.lblINstructions.Size = New System.Drawing.Size(713, 20)
        Me.lblINstructions.TabIndex = 1
        Me.lblINstructions.Text = "To become a courier, please upload a picture of your student ID card and drivers " &
    "license"
        '
        'btnUploadID
        '
        Me.btnUploadID.BackColor = System.Drawing.Color.Orange
        Me.btnUploadID.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnUploadID.ForeColor = System.Drawing.Color.White
        Me.btnUploadID.Location = New System.Drawing.Point(535, 282)
        Me.btnUploadID.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.btnUploadID.Name = "btnUploadID"
        Me.btnUploadID.Size = New System.Drawing.Size(195, 56)
        Me.btnUploadID.TabIndex = 8
        Me.btnUploadID.Text = "Upload Student ID Card"
        Me.btnUploadID.UseVisualStyleBackColor = False
        '
        'UploadLicense
        '
        Me.UploadLicense.BackColor = System.Drawing.Color.Orange
        Me.UploadLicense.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.UploadLicense.ForeColor = System.Drawing.Color.White
        Me.UploadLicense.Location = New System.Drawing.Point(535, 582)
        Me.UploadLicense.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.UploadLicense.Name = "UploadLicense"
        Me.UploadLicense.Size = New System.Drawing.Size(195, 56)
        Me.UploadLicense.TabIndex = 9
        Me.UploadLicense.Text = "Upload Drivers License"
        Me.UploadLicense.UseVisualStyleBackColor = False
        '
        'Button2
        '
        Me.Button2.BackColor = System.Drawing.Color.Orange
        Me.Button2.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button2.ForeColor = System.Drawing.Color.White
        Me.Button2.Location = New System.Drawing.Point(94, 797)
        Me.Button2.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(195, 56)
        Me.Button2.TabIndex = 10
        Me.Button2.Text = "Back"
        Me.Button2.UseVisualStyleBackColor = False
        '
        'btnRegister
        '
        Me.btnRegister.BackColor = System.Drawing.Color.Orange
        Me.btnRegister.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnRegister.ForeColor = System.Drawing.Color.White
        Me.btnRegister.Location = New System.Drawing.Point(535, 797)
        Me.btnRegister.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.btnRegister.Name = "btnRegister"
        Me.btnRegister.Size = New System.Drawing.Size(195, 56)
        Me.btnRegister.TabIndex = 11
        Me.btnRegister.Text = "Register"
        Me.btnRegister.UseVisualStyleBackColor = False
        '
        'picLicense
        '
        Me.picLicense.BackColor = System.Drawing.Color.SlateGray
        Me.picLicense.Location = New System.Drawing.Point(94, 505)
        Me.picLicense.Name = "picLicense"
        Me.picLicense.Size = New System.Drawing.Size(379, 210)
        Me.picLicense.TabIndex = 2
        Me.picLicense.TabStop = False
        '
        'picStudentCard
        '
        Me.picStudentCard.BackColor = System.Drawing.Color.LightSlateGray
        Me.picStudentCard.Location = New System.Drawing.Point(94, 210)
        Me.picStudentCard.Name = "picStudentCard"
        Me.picStudentCard.Size = New System.Drawing.Size(379, 210)
        Me.picStudentCard.TabIndex = 0
        Me.picStudentCard.TabStop = False
        '
        'CUSTOMER_Courier_Registration
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(9.0!, 20.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.MidnightBlue
        Me.ClientSize = New System.Drawing.Size(800, 906)
        Me.Controls.Add(Me.btnRegister)
        Me.Controls.Add(Me.Button2)
        Me.Controls.Add(Me.UploadLicense)
        Me.Controls.Add(Me.btnUploadID)
        Me.Controls.Add(Me.picLicense)
        Me.Controls.Add(Me.lblINstructions)
        Me.Controls.Add(Me.picStudentCard)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "CUSTOMER_Courier_Registration"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Courier Registration"
        CType(Me.picLicense, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picStudentCard, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents picStudentCard As PictureBox
    Friend WithEvents lblINstructions As Label
    Friend WithEvents picLicense As PictureBox
    Friend WithEvents btnUploadID As Button
    Friend WithEvents UploadLicense As Button
    Friend WithEvents Button2 As Button
    Friend WithEvents btnRegister As Button
End Class
