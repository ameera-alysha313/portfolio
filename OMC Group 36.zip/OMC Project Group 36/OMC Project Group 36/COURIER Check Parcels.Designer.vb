﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class COURIER_Check_Parcels
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(COURIER_Check_Parcels))
        Me.grdParcelData = New System.Windows.Forms.DataGridView()
        Me.ParcelDataBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.btnBack = New System.Windows.Forms.Button()
        Me.DeliverUS_DatabaseDataSet1 = New OMC_Project_Group_36.DeliverUS_DatabaseDataSet()
        Me.ParcelDataBindingSource1 = New System.Windows.Forms.BindingSource(Me.components)
        Me.ParcelDataTableAdapter1 = New OMC_Project_Group_36.DeliverUS_DatabaseDataSetTableAdapters.ParcelDataTableAdapter()
        Me.DataGridViewTextBoxColumn1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn2 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.ArrivalDateDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DeliveryStatusDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        CType(Me.grdParcelData, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.ParcelDataBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.DeliverUS_DatabaseDataSet1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.ParcelDataBindingSource1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'grdParcelData
        '
        Me.grdParcelData.AllowUserToAddRows = False
        Me.grdParcelData.AllowUserToDeleteRows = False
        Me.grdParcelData.AutoGenerateColumns = False
        Me.grdParcelData.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.grdParcelData.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.DataGridViewTextBoxColumn1, Me.DataGridViewTextBoxColumn2, Me.ArrivalDateDataGridViewTextBoxColumn, Me.DeliveryStatusDataGridViewTextBoxColumn})
        Me.grdParcelData.DataSource = Me.ParcelDataBindingSource1
        Me.grdParcelData.Location = New System.Drawing.Point(58, 72)
        Me.grdParcelData.Name = "grdParcelData"
        Me.grdParcelData.ReadOnly = True
        Me.grdParcelData.RowHeadersWidth = 62
        Me.grdParcelData.RowTemplate.Height = 28
        Me.grdParcelData.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.grdParcelData.Size = New System.Drawing.Size(427, 548)
        Me.grdParcelData.TabIndex = 0
        '
        'ParcelDataBindingSource
        '
        Me.ParcelDataBindingSource.DataMember = "ParcelData"
        '
        'btnBack
        '
        Me.btnBack.BackColor = System.Drawing.Color.Orange
        Me.btnBack.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnBack.ForeColor = System.Drawing.Color.White
        Me.btnBack.Location = New System.Drawing.Point(32, 645)
        Me.btnBack.Name = "btnBack"
        Me.btnBack.Size = New System.Drawing.Size(153, 41)
        Me.btnBack.TabIndex = 2
        Me.btnBack.Text = "Back"
        Me.btnBack.UseVisualStyleBackColor = False
        '
        'DeliverUS_DatabaseDataSet1
        '
        Me.DeliverUS_DatabaseDataSet1.DataSetName = "DeliverUS_DatabaseDataSet"
        Me.DeliverUS_DatabaseDataSet1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'ParcelDataBindingSource1
        '
        Me.ParcelDataBindingSource1.DataMember = "ParcelData"
        Me.ParcelDataBindingSource1.DataSource = Me.DeliverUS_DatabaseDataSet1
        '
        'ParcelDataTableAdapter1
        '
        Me.ParcelDataTableAdapter1.ClearBeforeFill = True
        '
        'DataGridViewTextBoxColumn1
        '
        Me.DataGridViewTextBoxColumn1.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.DisplayedCells
        Me.DataGridViewTextBoxColumn1.DataPropertyName = "TrackingNumber"
        Me.DataGridViewTextBoxColumn1.HeaderText = "TrackingNumber"
        Me.DataGridViewTextBoxColumn1.MinimumWidth = 8
        Me.DataGridViewTextBoxColumn1.Name = "DataGridViewTextBoxColumn1"
        Me.DataGridViewTextBoxColumn1.ReadOnly = True
        Me.DataGridViewTextBoxColumn1.Visible = False
        Me.DataGridViewTextBoxColumn1.Width = 161
        '
        'DataGridViewTextBoxColumn2
        '
        Me.DataGridViewTextBoxColumn2.DataPropertyName = "Size"
        Me.DataGridViewTextBoxColumn2.HeaderText = "Size"
        Me.DataGridViewTextBoxColumn2.MinimumWidth = 8
        Me.DataGridViewTextBoxColumn2.Name = "DataGridViewTextBoxColumn2"
        Me.DataGridViewTextBoxColumn2.ReadOnly = True
        Me.DataGridViewTextBoxColumn2.Width = 150
        '
        'ArrivalDateDataGridViewTextBoxColumn
        '
        Me.ArrivalDateDataGridViewTextBoxColumn.DataPropertyName = "ArrivalDate"
        Me.ArrivalDateDataGridViewTextBoxColumn.HeaderText = "ArrivalDate"
        Me.ArrivalDateDataGridViewTextBoxColumn.MinimumWidth = 8
        Me.ArrivalDateDataGridViewTextBoxColumn.Name = "ArrivalDateDataGridViewTextBoxColumn"
        Me.ArrivalDateDataGridViewTextBoxColumn.ReadOnly = True
        Me.ArrivalDateDataGridViewTextBoxColumn.Width = 150
        '
        'DeliveryStatusDataGridViewTextBoxColumn
        '
        Me.DeliveryStatusDataGridViewTextBoxColumn.DataPropertyName = "DeliveryStatus"
        Me.DeliveryStatusDataGridViewTextBoxColumn.HeaderText = "DeliveryStatus"
        Me.DeliveryStatusDataGridViewTextBoxColumn.MinimumWidth = 8
        Me.DeliveryStatusDataGridViewTextBoxColumn.Name = "DeliveryStatusDataGridViewTextBoxColumn"
        Me.DeliveryStatusDataGridViewTextBoxColumn.ReadOnly = True
        Me.DeliveryStatusDataGridViewTextBoxColumn.Visible = False
        Me.DeliveryStatusDataGridViewTextBoxColumn.Width = 150
        '
        'COURIER_Check_Parcels
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(9.0!, 20.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.MidnightBlue
        Me.ClientSize = New System.Drawing.Size(561, 698)
        Me.Controls.Add(Me.btnBack)
        Me.Controls.Add(Me.grdParcelData)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "COURIER_Check_Parcels"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Available Parcels"
        CType(Me.grdParcelData, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.ParcelDataBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.DeliverUS_DatabaseDataSet1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.ParcelDataBindingSource1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents grdParcelData As DataGridView
    Friend WithEvents DeliverUS_DatabaseDataSet As DeliverUS_DatabaseDataSet
    Friend WithEvents ParcelDataBindingSource As BindingSource
    Friend WithEvents ParcelDataTableAdapter As DeliverUS_DatabaseDataSetTableAdapters.ParcelDataTableAdapter
    Friend WithEvents TrackingNumberDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents SizeDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents btnBack As Button
    Friend WithEvents DeliverUS_DatabaseDataSet1 As DeliverUS_DatabaseDataSet
    Friend WithEvents ParcelDataBindingSource1 As BindingSource
    Friend WithEvents ParcelDataTableAdapter1 As DeliverUS_DatabaseDataSetTableAdapters.ParcelDataTableAdapter
    Friend WithEvents DataGridViewTextBoxColumn1 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn2 As DataGridViewTextBoxColumn
    Friend WithEvents ArrivalDateDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents DeliveryStatusDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
End Class
