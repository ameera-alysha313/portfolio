﻿Public Class COURIER_Check_Parcels

    Public TrackingNumber As String

    Private Sub COURIER_Check_Parcels_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'DeliverUS_DatabaseDataSet1.ParcelData' table. You can move, or remove it, as needed.
        Me.ParcelDataTableAdapter1.Fill(Me.DeliverUS_DatabaseDataSet1.ParcelData)

        ParcelDataBindingSource1.Filter = $"DeliveryStatus LIKE '{"Arrived"}%'"

    End Sub


    Public Sub ParcelData_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles grdParcelData.CellContentClick
        Me.TrackingNumber = grdParcelData.CurrentRow.Cells(0).Value.ToString
        COURIER_Parcel_Details.txtSize.Text = grdParcelData.CurrentRow.Cells(1).Value.ToString
        COURIER_Parcel_Details.txtDate.Text = grdParcelData.CurrentRow.Cells(2).Value.ToString

        COURIER_Parcel_Details.Show()

    End Sub


    Private Sub btnBack_Click(sender As Object, e As EventArgs) Handles btnBack.Click
        Me.Close()
        COURIER_Main_Menu.Show()
    End Sub
End Class