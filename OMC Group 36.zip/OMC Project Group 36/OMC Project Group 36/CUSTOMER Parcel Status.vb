﻿Imports System.Data.OleDb
Imports System.Windows.Forms.VisualStyles.VisualStyleElement

Public Class CUSTOMER_Parcel_Status

    Dim conn As New OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" & Application.StartupPath & "\DeliverUS_Database.accdb")
    Dim cmd As OleDbCommand
    Dim dt As New DataTable
    Dim da As New OleDbDataAdapter(cmd)


    Private Sub btnAddParcel_Click(sender As Object, e As EventArgs) Handles btnAddParcel.Click
        CUSTOMER_Register_Parcel.Show()
    End Sub

    Private Sub btnTrack_Click(sender As Object, e As EventArgs) Handles btnTrack.Click

        'Search for parcel in records

        Dim temp As Integer = 0

        For i As Integer = 0 To grdParcels.RowCount - 1

            If grdParcels.Rows(i).Cells(0).Value.ToString = txtTracking.Text Then
                grdParcels.Rows(i).Selected = True
                MsgBox("Parcel found")
                temp = 1
            End If

        Next

        If temp = 0 Then
            MsgBox("Record not found")
        End If


    End Sub

    Private Sub btnBack_Click(sender As Object, e As EventArgs) Handles btnBack.Click
        Me.Dispose()
        Me.Hide()
        CUSTOMER_Main_Menu.Show()
    End Sub


    Private Sub CUSTOMER_Parcel_Status_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'DeliverUS_DatabaseDataSet2.ParcelData' table. You can move, or remove it, as needed.
        Me.ParcelDataTableAdapter2.Fill(Me.DeliverUS_DatabaseDataSet2.ParcelData)
        'TODO: This line of code loads data into the 'DeliverUS_DatabaseDataSet1.ParcelData' table. You can move, or remove it, as needed.
        Me.ParcelDataTableAdapter1.Fill(Me.DeliverUS_DatabaseDataSet1.ParcelData)

        ParcelDataBindingSource4.Filter = $"CustomerID LIKE '{StudentID}%'"


    End Sub

    Private Sub grdParcels_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles grdParcels.CellContentClick

    End Sub
End Class