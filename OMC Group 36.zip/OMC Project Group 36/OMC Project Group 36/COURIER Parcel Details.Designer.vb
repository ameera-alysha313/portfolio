﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class COURIER_Parcel_Details
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(COURIER_Parcel_Details))
        Me.lblGender = New System.Windows.Forms.Label()
        Me.lblPhone = New System.Windows.Forms.Label()
        Me.txtAddress = New System.Windows.Forms.TextBox()
        Me.lblName = New System.Windows.Forms.Label()
        Me.txtSize = New System.Windows.Forms.TextBox()
        Me.txtDate = New System.Windows.Forms.TextBox()
        Me.btnCancel = New System.Windows.Forms.Button()
        Me.btnDeliverParcel = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'lblGender
        '
        Me.lblGender.AutoSize = True
        Me.lblGender.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblGender.ForeColor = System.Drawing.Color.White
        Me.lblGender.Location = New System.Drawing.Point(98, 163)
        Me.lblGender.Name = "lblGender"
        Me.lblGender.Size = New System.Drawing.Size(103, 20)
        Me.lblGender.TabIndex = 92
        Me.lblGender.Text = "Arrival Date"
        '
        'lblPhone
        '
        Me.lblPhone.AutoSize = True
        Me.lblPhone.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblPhone.ForeColor = System.Drawing.Color.White
        Me.lblPhone.Location = New System.Drawing.Point(98, 255)
        Me.lblPhone.Name = "lblPhone"
        Me.lblPhone.Size = New System.Drawing.Size(143, 20)
        Me.lblPhone.TabIndex = 87
        Me.lblPhone.Text = "Delivery Address"
        '
        'txtAddress
        '
        Me.txtAddress.Location = New System.Drawing.Point(101, 279)
        Me.txtAddress.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.txtAddress.Name = "txtAddress"
        Me.txtAddress.ReadOnly = True
        Me.txtAddress.Size = New System.Drawing.Size(384, 26)
        Me.txtAddress.TabIndex = 86
        '
        'lblName
        '
        Me.lblName.AutoSize = True
        Me.lblName.BackColor = System.Drawing.Color.Transparent
        Me.lblName.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblName.ForeColor = System.Drawing.Color.White
        Me.lblName.Location = New System.Drawing.Point(98, 85)
        Me.lblName.Name = "lblName"
        Me.lblName.Size = New System.Drawing.Size(44, 20)
        Me.lblName.TabIndex = 85
        Me.lblName.Text = "Size"
        '
        'txtSize
        '
        Me.txtSize.Location = New System.Drawing.Point(101, 108)
        Me.txtSize.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.txtSize.Name = "txtSize"
        Me.txtSize.ReadOnly = True
        Me.txtSize.Size = New System.Drawing.Size(150, 26)
        Me.txtSize.TabIndex = 84
        '
        'txtDate
        '
        Me.txtDate.Location = New System.Drawing.Point(100, 187)
        Me.txtDate.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.txtDate.Name = "txtDate"
        Me.txtDate.ReadOnly = True
        Me.txtDate.Size = New System.Drawing.Size(190, 26)
        Me.txtDate.TabIndex = 93
        '
        'btnCancel
        '
        Me.btnCancel.BackColor = System.Drawing.Color.Orange
        Me.btnCancel.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnCancel.ForeColor = System.Drawing.Color.White
        Me.btnCancel.Location = New System.Drawing.Point(36, 382)
        Me.btnCancel.Name = "btnCancel"
        Me.btnCancel.Size = New System.Drawing.Size(153, 41)
        Me.btnCancel.TabIndex = 94
        Me.btnCancel.Text = "Cancel"
        Me.btnCancel.UseVisualStyleBackColor = False
        '
        'btnDeliverParcel
        '
        Me.btnDeliverParcel.BackColor = System.Drawing.Color.Orange
        Me.btnDeliverParcel.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnDeliverParcel.ForeColor = System.Drawing.Color.White
        Me.btnDeliverParcel.Location = New System.Drawing.Point(440, 382)
        Me.btnDeliverParcel.Name = "btnDeliverParcel"
        Me.btnDeliverParcel.Size = New System.Drawing.Size(153, 41)
        Me.btnDeliverParcel.TabIndex = 95
        Me.btnDeliverParcel.Text = "Deliver Parcel"
        Me.btnDeliverParcel.UseVisualStyleBackColor = False
        '
        'COURIER_Parcel_Details
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(9.0!, 20.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.MidnightBlue
        Me.ClientSize = New System.Drawing.Size(636, 472)
        Me.Controls.Add(Me.btnDeliverParcel)
        Me.Controls.Add(Me.btnCancel)
        Me.Controls.Add(Me.lblGender)
        Me.Controls.Add(Me.lblPhone)
        Me.Controls.Add(Me.txtAddress)
        Me.Controls.Add(Me.lblName)
        Me.Controls.Add(Me.txtSize)
        Me.Controls.Add(Me.txtDate)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "COURIER_Parcel_Details"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Parcel Details"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents lblGender As Label
    Friend WithEvents lblPhone As Label
    Public WithEvents txtAddress As TextBox
    Friend WithEvents lblName As Label
    Public WithEvents txtSize As TextBox
    Public WithEvents txtDate As TextBox
    Friend WithEvents btnCancel As Button
    Friend WithEvents btnDeliverParcel As Button
End Class
