﻿Imports System.Data.OleDb

Public Class CUSTOMER_Register_Parcel
    Dim conn As New OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" & Application.StartupPath & "\DeliverUS_Database.accdb")
    Dim cmd As OleDbCommand
    Dim dt As New DataTable
    Dim da As New OleDbDataAdapter(cmd)
    Dim dr As OleDbDataReader

    Private Sub btnCancel_Click(sender As Object, e As EventArgs) Handles btnCancel.Click
        Me.Dispose()
        Me.Close()
    End Sub

    Public Sub btnAdd_Click(sender As Object, e As EventArgs) Handles btnAdd.Click

        Try
            conn.Open()
            Dim cmd As New OleDbCommand("insert into ParcelData(`TrackingNumber`,`Size`, `CustomerID`, `DeliveryStatus`) values(@TrackingNumber, @Size, @CustomerID, @DeliveryStatus)", conn)

            cmd.Parameters.Clear()
            cmd.Parameters.AddWithValue("@TrackingNumber", txtTracking.Text)
            cmd.Parameters.AddWithValue("@Size", cbSize.Text)
            cmd.Parameters.AddWithValue("@CustomerID", StudentID) ' CustomerID is the ID of the usre currently logged in
            cmd.Parameters.AddWithValue("@DeliveryStatus", "Shipping") 'Delivery status is automatically set to shipping when user adds parcel.

            If cmd.ExecuteNonQuery > 0 Then

                MsgBox("Registration successful!", vbInformation)
                Me.Close()

                txtTracking.Clear()
                cbSize.SelectedIndex = -1
                Me.Dispose()

                CUSTOMER_Method_Of_Payment.Show()

            Else
                MsgBox("Registration failed. Try again.", vbCritical)
            End If


        Catch ex As Exception
            MsgBox(ex.Message)
        End Try


        conn.Close()
    End Sub
End Class