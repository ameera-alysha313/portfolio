﻿Imports System.Data.OleDb
Imports System.Drawing.Configuration

Public Class CUSTOMER_Courier_Registration

    Dim conn As New OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" & Application.StartupPath & "\DeliverUS_Database.accdb")
    Dim cmd As OleDbCommand
    Dim dt As New DataTable
    Dim da As New OleDbDataAdapter(cmd)
    Dim dr As OleDbDataReader

    ' User must upload a picture of their Student ID Card and drivers license to become a courier
    Private Sub btnUploadID_Click(sender As Object, e As EventArgs) Handles btnUploadID.Click
        Dim ofd As OpenFileDialog

        If ofd.ShowDialog = Windows.Forms.DialogResult.Cancel Then Exit Sub
        picStudentCard.Image = Image.FromFile(ofd.FileName)

    End Sub

    Private Sub UploadLicense_Click(sender As Object, e As EventArgs) Handles UploadLicense.Click
        Dim ofd As OpenFileDialog

        If ofd.ShowDialog = Windows.Forms.DialogResult.Cancel Then Exit Sub
        picLicense.Image = Image.FromFile(ofd.FileName)

    End Sub

    Private Sub btnRegister_Click(sender As Object, e As EventArgs) Handles btnRegister.Click
        conn.Open()
        Dim cmd As New OleDbCommand("insert into UserData(`StudentCard`,`License`) values(@StudentID,@License) where @StudentID=Login.StudentID", conn)

        Dim filesize As UInt32
        Dim mstream As IO.MemoryStream

        picStudentCard.Image.Save(mstream, System.Drawing.Imaging.ImageFormat.Jpeg)
        Dim studentcard() As Byte = mstream.GetBuffer
        filesize = mstream.Length
        mstream.Close()

        picLicense.Image.Save(mstream, System.Drawing.Imaging.ImageFormat.Jpeg)
        Dim license() As Byte = mstream.GetBuffer
        filesize = mstream.Length
        mstream.Close()


        cmd.Parameters.Clear()
        cmd.Parameters.AddWithValue("@StudentCard", studentcard)
        cmd.Parameters.AddWithValue("@License", license)



    End Sub
End Class