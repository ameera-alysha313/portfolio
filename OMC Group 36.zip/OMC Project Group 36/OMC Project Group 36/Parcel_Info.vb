﻿Public Class Parcel_Info

End Class