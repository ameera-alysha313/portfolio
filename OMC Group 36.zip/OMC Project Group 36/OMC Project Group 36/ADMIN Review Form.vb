﻿Imports System.Data.OleDb

Public Class ADMIN_Review_Form
    Dim conn As New OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" & Application.StartupPath & "\DeliverUS_Database.accdb")
    Dim cmd As OleDbCommand
    Dim constr As String
    Dim dt As New DataTable
    Dim da As New OleDbDataAdapter(cmd)


    Dim starRating As Integer = ADMIN_Review_List.starRating


    Public Sub ADMIN_Review_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'make number of stars filled change based on customers rating
        If starRating >= 1 Then
            btn1Star.Image = My.Resources.starfill
        End If

        If starRating >= 2 Then
            btn2Star.Image = My.Resources.starfill
        End If

        If starRating >= 1 Then
            btn3Star.Image = My.Resources.starfill
        End If

        If starRating >= 4 Then
            btn4Star.Image = My.Resources.starfill
        End If

        If starRating = 5 Then
            btn5Star.Image = My.Resources.starfill
        End If





    End Sub

    Private Sub ADMIN_Review_FormClosed(sender As Object, e As FormClosedEventArgs) Handles MyBase.FormClosed
        ADMIN_Main_Menu.Show()
    End Sub


End Class