﻿Imports System.Data.OleDb

Public Class COURIER_Main_Menu

    Dim conn As New OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" & Application.StartupPath & "\DeliverUS_Database.accdb")
    Dim cmd As OleDbCommand
    Dim dt As New DataTable
    Dim da As New OleDbDataAdapter(cmd)

    Public Sub COURIER_Main_Menu_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Dim dr As OleDbDataReader

        conn.Open()
        Dim cmd As New OleDbCommand("select*from AdminData where StudentID=@StudentID", conn)
        cmd.Parameters.Clear()
        cmd.Parameters.AddWithValue("@StudentID", StudentID)

        dr = cmd.ExecuteReader


        ' If user is an admin they will have access to Admin menu
        If dr.Read() = True Then
            btnAdminMenu.Show()
        End If

        conn.Close()

    End Sub


    Private Sub btnAdminMenu_Click(sender As Object, e As EventArgs) Handles btnAdminMenu.Click
        Me.Hide()
        ADMIN_Main_Menu.Show()
    End Sub


    Private Sub btnCustomerMenu_Click(sender As Object, e As EventArgs) Handles btnCustomerMenu.Click
        Me.Hide()
        CUSTOMER_Main_Menu.Show()
    End Sub


    Private Sub btnUserProfile_Click(sender As Object, e As EventArgs) Handles btnUserProfile.Click
        Me.Hide()
        COURIER_User_Profile.Show()
    End Sub


    Private Sub btnCheckParcels_Click(sender As Object, e As EventArgs) Handles btnCheckParcels.Click
        COURIER_Check_Parcels.Show()
        Me.Hide()
    End Sub


    Private Sub btnStatus_Click(sender As Object, e As EventArgs) Handles btnStatus.Click
        COURIER_Delivery_Status.Show()
        Me.Hide()
    End Sub


    Private Sub btnLogOut_Click(sender As Object, e As EventArgs) Handles btnLogOut.Click
        Dim result As Integer
        result = MsgBox("Are you sure you want to log out?", vbYesNo + vbExclamation, "Logging out...")

        If result = vbYes Then
            StudentID = ""

            Me.Close()
            Starting_Menu.Show()

        End If
    End Sub


    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Dim result As Integer
        result = MsgBox("Are you sure you want to exit the application?", vbYesNo + vbExclamation, "Exiting Apllication")

        If result = vbYes Then
            Application.Exit()
        End If
    End Sub


End Class