﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class ADMIN_Review_List
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(ADMIN_Review_List))
        Me.ReviewDataBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.DeliverUS_DatabaseDataSet = New OMC_Project_Group_36.DeliverUS_DatabaseDataSet()
        Me.ReviewDataTableAdapter = New OMC_Project_Group_36.DeliverUS_DatabaseDataSetTableAdapters.ReviewDataTableAdapter()
        Me.btnBack = New System.Windows.Forms.Button()
        Me.ReviewDataBindingSource1 = New System.Windows.Forms.BindingSource(Me.components)
        Me.grdReviewList = New System.Windows.Forms.DataGridView()
        Me.IDDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.ReviewDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.RatingDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.ReviewDataBindingSource2 = New System.Windows.Forms.BindingSource(Me.components)
        CType(Me.ReviewDataBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.DeliverUS_DatabaseDataSet, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.ReviewDataBindingSource1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.grdReviewList, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.ReviewDataBindingSource2, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'ReviewDataBindingSource
        '
        Me.ReviewDataBindingSource.DataMember = "ReviewData"
        Me.ReviewDataBindingSource.DataSource = Me.DeliverUS_DatabaseDataSet
        '
        'DeliverUS_DatabaseDataSet
        '
        Me.DeliverUS_DatabaseDataSet.DataSetName = "DeliverUS_DatabaseDataSet"
        Me.DeliverUS_DatabaseDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'ReviewDataTableAdapter
        '
        Me.ReviewDataTableAdapter.ClearBeforeFill = True
        '
        'btnBack
        '
        Me.btnBack.BackColor = System.Drawing.Color.Orange
        Me.btnBack.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnBack.ForeColor = System.Drawing.Color.White
        Me.btnBack.Location = New System.Drawing.Point(44, 585)
        Me.btnBack.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.btnBack.Name = "btnBack"
        Me.btnBack.Size = New System.Drawing.Size(146, 51)
        Me.btnBack.TabIndex = 122
        Me.btnBack.Text = "Back"
        Me.btnBack.UseVisualStyleBackColor = False
        '
        'ReviewDataBindingSource1
        '
        Me.ReviewDataBindingSource1.DataMember = "ReviewData"
        Me.ReviewDataBindingSource1.DataSource = Me.DeliverUS_DatabaseDataSet
        '
        'grdReviewList
        '
        Me.grdReviewList.AllowUserToAddRows = False
        Me.grdReviewList.AllowUserToDeleteRows = False
        Me.grdReviewList.AutoGenerateColumns = False
        Me.grdReviewList.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.grdReviewList.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.IDDataGridViewTextBoxColumn, Me.ReviewDataGridViewTextBoxColumn, Me.RatingDataGridViewTextBoxColumn})
        Me.grdReviewList.DataSource = Me.ReviewDataBindingSource2
        Me.grdReviewList.Location = New System.Drawing.Point(77, 118)
        Me.grdReviewList.Name = "grdReviewList"
        Me.grdReviewList.ReadOnly = True
        Me.grdReviewList.RowHeadersWidth = 62
        Me.grdReviewList.RowTemplate.Height = 28
        Me.grdReviewList.Size = New System.Drawing.Size(810, 375)
        Me.grdReviewList.TabIndex = 123
        '
        'IDDataGridViewTextBoxColumn
        '
        Me.IDDataGridViewTextBoxColumn.DataPropertyName = "ID"
        Me.IDDataGridViewTextBoxColumn.HeaderText = "ID"
        Me.IDDataGridViewTextBoxColumn.MinimumWidth = 8
        Me.IDDataGridViewTextBoxColumn.Name = "IDDataGridViewTextBoxColumn"
        Me.IDDataGridViewTextBoxColumn.ReadOnly = True
        Me.IDDataGridViewTextBoxColumn.Visible = False
        Me.IDDataGridViewTextBoxColumn.Width = 150
        '
        'ReviewDataGridViewTextBoxColumn
        '
        Me.ReviewDataGridViewTextBoxColumn.DataPropertyName = "Review"
        Me.ReviewDataGridViewTextBoxColumn.HeaderText = "Review"
        Me.ReviewDataGridViewTextBoxColumn.MinimumWidth = 8
        Me.ReviewDataGridViewTextBoxColumn.Name = "ReviewDataGridViewTextBoxColumn"
        Me.ReviewDataGridViewTextBoxColumn.ReadOnly = True
        Me.ReviewDataGridViewTextBoxColumn.Width = 150
        '
        'RatingDataGridViewTextBoxColumn
        '
        Me.RatingDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.DisplayedCells
        Me.RatingDataGridViewTextBoxColumn.DataPropertyName = "Rating"
        Me.RatingDataGridViewTextBoxColumn.HeaderText = "Rating"
        Me.RatingDataGridViewTextBoxColumn.MinimumWidth = 8
        Me.RatingDataGridViewTextBoxColumn.Name = "RatingDataGridViewTextBoxColumn"
        Me.RatingDataGridViewTextBoxColumn.ReadOnly = True
        Me.RatingDataGridViewTextBoxColumn.Width = 92
        '
        'ReviewDataBindingSource2
        '
        Me.ReviewDataBindingSource2.DataMember = "ReviewData"
        Me.ReviewDataBindingSource2.DataSource = Me.DeliverUS_DatabaseDataSet
        '
        'ADMIN_Review_List
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(9.0!, 20.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.MidnightBlue
        Me.ClientSize = New System.Drawing.Size(995, 710)
        Me.Controls.Add(Me.grdReviewList)
        Me.Controls.Add(Me.btnBack)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "ADMIN_Review_List"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Customer Reviews"
        CType(Me.ReviewDataBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.DeliverUS_DatabaseDataSet, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.ReviewDataBindingSource1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.grdReviewList, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.ReviewDataBindingSource2, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents DeliverUS_DatabaseDataSet As DeliverUS_DatabaseDataSet
    Friend WithEvents ReviewDataBindingSource As BindingSource
    Friend WithEvents ReviewDataTableAdapter As DeliverUS_DatabaseDataSetTableAdapters.ReviewDataTableAdapter
    Friend WithEvents btnBack As Button
    Friend WithEvents ReviewDataBindingSource1 As BindingSource
    Friend WithEvents grdReviewList As DataGridView
    Friend WithEvents IDDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents ReviewDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents RatingDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents ReviewDataBindingSource2 As BindingSource
End Class
