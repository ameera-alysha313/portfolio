﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class COURIER_Main_Menu
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(COURIER_Main_Menu))
        Me.btnLogOut = New System.Windows.Forms.Button()
        Me.btnExit = New System.Windows.Forms.Button()
        Me.btnCheckParcels = New System.Windows.Forms.Button()
        Me.btnStatus = New System.Windows.Forms.Button()
        Me.btnUserProfile = New System.Windows.Forms.Button()
        Me.btnCustomerMenu = New System.Windows.Forms.Button()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.btnAdminMenu = New System.Windows.Forms.Button()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'btnLogOut
        '
        Me.btnLogOut.BackColor = System.Drawing.Color.Orange
        Me.btnLogOut.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnLogOut.ForeColor = System.Drawing.Color.White
        Me.btnLogOut.Location = New System.Drawing.Point(206, 389)
        Me.btnLogOut.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.btnLogOut.Name = "btnLogOut"
        Me.btnLogOut.Size = New System.Drawing.Size(153, 56)
        Me.btnLogOut.TabIndex = 17
        Me.btnLogOut.Text = "Log Out"
        Me.btnLogOut.UseVisualStyleBackColor = False
        '
        'btnExit
        '
        Me.btnExit.BackColor = System.Drawing.Color.Orange
        Me.btnExit.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnExit.ForeColor = System.Drawing.Color.White
        Me.btnExit.Location = New System.Drawing.Point(465, 389)
        Me.btnExit.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Size = New System.Drawing.Size(153, 56)
        Me.btnExit.TabIndex = 16
        Me.btnExit.Text = "Exit"
        Me.btnExit.UseVisualStyleBackColor = False
        '
        'btnCheckParcels
        '
        Me.btnCheckParcels.BackColor = System.Drawing.Color.Orange
        Me.btnCheckParcels.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnCheckParcels.ForeColor = System.Drawing.Color.White
        Me.btnCheckParcels.Location = New System.Drawing.Point(49, 272)
        Me.btnCheckParcels.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.btnCheckParcels.Name = "btnCheckParcels"
        Me.btnCheckParcels.Size = New System.Drawing.Size(153, 56)
        Me.btnCheckParcels.TabIndex = 15
        Me.btnCheckParcels.Text = "Check Parcels"
        Me.btnCheckParcels.UseVisualStyleBackColor = False
        '
        'btnStatus
        '
        Me.btnStatus.BackColor = System.Drawing.Color.Orange
        Me.btnStatus.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnStatus.ForeColor = System.Drawing.Color.White
        Me.btnStatus.Location = New System.Drawing.Point(323, 272)
        Me.btnStatus.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.btnStatus.Name = "btnStatus"
        Me.btnStatus.Size = New System.Drawing.Size(153, 56)
        Me.btnStatus.TabIndex = 14
        Me.btnStatus.Text = "Delivery Status"
        Me.btnStatus.UseVisualStyleBackColor = False
        '
        'btnUserProfile
        '
        Me.btnUserProfile.BackColor = System.Drawing.Color.Orange
        Me.btnUserProfile.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnUserProfile.ForeColor = System.Drawing.Color.White
        Me.btnUserProfile.Location = New System.Drawing.Point(614, 272)
        Me.btnUserProfile.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.btnUserProfile.Name = "btnUserProfile"
        Me.btnUserProfile.Size = New System.Drawing.Size(153, 56)
        Me.btnUserProfile.TabIndex = 13
        Me.btnUserProfile.Text = "View Profile"
        Me.btnUserProfile.UseVisualStyleBackColor = False
        '
        'btnCustomerMenu
        '
        Me.btnCustomerMenu.BackColor = System.Drawing.Color.Orange
        Me.btnCustomerMenu.ForeColor = System.Drawing.Color.White
        Me.btnCustomerMenu.Location = New System.Drawing.Point(614, 50)
        Me.btnCustomerMenu.Name = "btnCustomerMenu"
        Me.btnCustomerMenu.Size = New System.Drawing.Size(191, 56)
        Me.btnCustomerMenu.TabIndex = 19
        Me.btnCustomerMenu.Text = "Switch to" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Customer Menu"
        Me.btnCustomerMenu.UseVisualStyleBackColor = False
        '
        'PictureBox1
        '
        Me.PictureBox1.BackColor = System.Drawing.Color.Transparent
        Me.PictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.PictureBox1.Image = Global.OMC_Project_Group_36.My.Resources.Resources.DeliverUS_Logo
        Me.PictureBox1.Location = New System.Drawing.Point(290, 50)
        Me.PictureBox1.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(234, 190)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox1.TabIndex = 18
        Me.PictureBox1.TabStop = False
        '
        'btnAdminMenu
        '
        Me.btnAdminMenu.BackColor = System.Drawing.Color.Orange
        Me.btnAdminMenu.ForeColor = System.Drawing.Color.White
        Me.btnAdminMenu.Location = New System.Drawing.Point(614, 112)
        Me.btnAdminMenu.Name = "btnAdminMenu"
        Me.btnAdminMenu.Size = New System.Drawing.Size(191, 35)
        Me.btnAdminMenu.TabIndex = 20
        Me.btnAdminMenu.Text = "Switch to Admin Menu"
        Me.btnAdminMenu.UseVisualStyleBackColor = False
        Me.btnAdminMenu.Visible = False
        '
        'COURIER_Main_Menu
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(9.0!, 20.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.MidnightBlue
        Me.ClientSize = New System.Drawing.Size(842, 500)
        Me.Controls.Add(Me.btnAdminMenu)
        Me.Controls.Add(Me.btnCustomerMenu)
        Me.Controls.Add(Me.PictureBox1)
        Me.Controls.Add(Me.btnLogOut)
        Me.Controls.Add(Me.btnExit)
        Me.Controls.Add(Me.btnCheckParcels)
        Me.Controls.Add(Me.btnStatus)
        Me.Controls.Add(Me.btnUserProfile)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "COURIER_Main_Menu"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Main Menu"
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents btnLogOut As Button
    Friend WithEvents btnExit As Button
    Friend WithEvents btnCheckParcels As Button
    Friend WithEvents btnStatus As Button
    Friend WithEvents btnUserProfile As Button
    Friend WithEvents btnCustomerMenu As Button
    Friend WithEvents btnAdminMenu As Button
End Class
