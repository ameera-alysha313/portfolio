﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class CUSTOMER_Parcel_Status
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(CUSTOMER_Parcel_Status))
        Me.ParcelDataBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.btnTrack = New System.Windows.Forms.Button()
        Me.txtTracking = New System.Windows.Forms.TextBox()
        Me.lblTracking = New System.Windows.Forms.Label()
        Me.lblTrack = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.btnAddParcel = New System.Windows.Forms.Button()
        Me.btnBack = New System.Windows.Forms.Button()
        Me.ParcelDataBindingSource1 = New System.Windows.Forms.BindingSource(Me.components)
        Me.ParcelDataBindingSource2 = New System.Windows.Forms.BindingSource(Me.components)
        Me.grdParcels = New System.Windows.Forms.DataGridView()
        Me.ParcelDataBindingSource4 = New System.Windows.Forms.BindingSource(Me.components)
        Me.ParcelDataBindingSource3 = New System.Windows.Forms.BindingSource(Me.components)
        Me.DeliverUS_DatabaseDataSet2 = New OMC_Project_Group_36.DeliverUS_DatabaseDataSet()
        Me.ParcelDataBindingSource5 = New System.Windows.Forms.BindingSource(Me.components)
        Me.ParcelDataTableAdapter2 = New OMC_Project_Group_36.DeliverUS_DatabaseDataSetTableAdapters.ParcelDataTableAdapter()
        Me.DataGridViewTextBoxColumn8 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn9 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn10 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn11 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn12 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn13 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        CType(Me.ParcelDataBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.ParcelDataBindingSource1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.ParcelDataBindingSource2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.grdParcels, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.ParcelDataBindingSource4, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.ParcelDataBindingSource3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.DeliverUS_DatabaseDataSet2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.ParcelDataBindingSource5, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'ParcelDataBindingSource
        '
        Me.ParcelDataBindingSource.DataMember = "ParcelData"
        '
        'btnTrack
        '
        Me.btnTrack.BackColor = System.Drawing.Color.Orange
        Me.btnTrack.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnTrack.ForeColor = System.Drawing.Color.White
        Me.btnTrack.Location = New System.Drawing.Point(558, 179)
        Me.btnTrack.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.btnTrack.Name = "btnTrack"
        Me.btnTrack.Size = New System.Drawing.Size(141, 30)
        Me.btnTrack.TabIndex = 39
        Me.btnTrack.Text = "Track"
        Me.btnTrack.UseVisualStyleBackColor = False
        '
        'txtTracking
        '
        Me.txtTracking.Location = New System.Drawing.Point(288, 183)
        Me.txtTracking.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.txtTracking.Name = "txtTracking"
        Me.txtTracking.Size = New System.Drawing.Size(253, 26)
        Me.txtTracking.TabIndex = 38
        '
        'lblTracking
        '
        Me.lblTracking.AutoSize = True
        Me.lblTracking.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTracking.ForeColor = System.Drawing.Color.White
        Me.lblTracking.Location = New System.Drawing.Point(65, 179)
        Me.lblTracking.Name = "lblTracking"
        Me.lblTracking.Size = New System.Drawing.Size(222, 29)
        Me.lblTracking.TabIndex = 37
        Me.lblTracking.Text = "Tracking Number:"
        '
        'lblTrack
        '
        Me.lblTrack.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.lblTrack.AutoSize = True
        Me.lblTrack.Font = New System.Drawing.Font("Microsoft Sans Serif", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTrack.ForeColor = System.Drawing.Color.White
        Me.lblTrack.Location = New System.Drawing.Point(247, 93)
        Me.lblTrack.Name = "lblTrack"
        Me.lblTrack.Size = New System.Drawing.Size(323, 40)
        Me.lblTrack.TabIndex = 36
        Me.lblTrack.Text = "Track your parcel!"
        '
        'Label1
        '
        Me.Label1.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.White
        Me.Label1.Location = New System.Drawing.Point(371, 246)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(58, 32)
        Me.Label1.TabIndex = 40
        Me.Label1.Text = "OR"
        '
        'btnAddParcel
        '
        Me.btnAddParcel.BackColor = System.Drawing.Color.Orange
        Me.btnAddParcel.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnAddParcel.ForeColor = System.Drawing.Color.White
        Me.btnAddParcel.Location = New System.Drawing.Point(326, 310)
        Me.btnAddParcel.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.btnAddParcel.Name = "btnAddParcel"
        Me.btnAddParcel.Size = New System.Drawing.Size(148, 41)
        Me.btnAddParcel.TabIndex = 41
        Me.btnAddParcel.Text = "Add New Parcel"
        Me.btnAddParcel.UseVisualStyleBackColor = False
        '
        'btnBack
        '
        Me.btnBack.BackColor = System.Drawing.Color.Orange
        Me.btnBack.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnBack.ForeColor = System.Drawing.Color.White
        Me.btnBack.Location = New System.Drawing.Point(25, 798)
        Me.btnBack.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.btnBack.Name = "btnBack"
        Me.btnBack.Size = New System.Drawing.Size(146, 51)
        Me.btnBack.TabIndex = 50
        Me.btnBack.Text = "Back"
        Me.btnBack.UseVisualStyleBackColor = False
        '
        'ParcelDataBindingSource1
        '
        Me.ParcelDataBindingSource1.DataMember = "ParcelData"
        '
        'ParcelDataBindingSource2
        '
        Me.ParcelDataBindingSource2.DataMember = "ParcelData"
        '
        'grdParcels
        '
        Me.grdParcels.AllowUserToAddRows = False
        Me.grdParcels.AllowUserToDeleteRows = False
        Me.grdParcels.AutoGenerateColumns = False
        Me.grdParcels.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.grdParcels.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.DataGridViewTextBoxColumn8, Me.DataGridViewTextBoxColumn9, Me.DataGridViewTextBoxColumn10, Me.DataGridViewTextBoxColumn11, Me.DataGridViewTextBoxColumn12, Me.DataGridViewTextBoxColumn13})
        Me.grdParcels.DataSource = Me.ParcelDataBindingSource5
        Me.grdParcels.Location = New System.Drawing.Point(51, 401)
        Me.grdParcels.Name = "grdParcels"
        Me.grdParcels.ReadOnly = True
        Me.grdParcels.RowHeadersWidth = 62
        Me.grdParcels.RowTemplate.Height = 28
        Me.grdParcels.Size = New System.Drawing.Size(662, 333)
        Me.grdParcels.TabIndex = 51
        '
        'ParcelDataBindingSource4
        '
        Me.ParcelDataBindingSource4.DataMember = "ParcelData"
        '
        'ParcelDataBindingSource3
        '
        Me.ParcelDataBindingSource3.DataMember = "ParcelData"
        '
        'DeliverUS_DatabaseDataSet2
        '
        Me.DeliverUS_DatabaseDataSet2.DataSetName = "DeliverUS_DatabaseDataSet"
        Me.DeliverUS_DatabaseDataSet2.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'ParcelDataBindingSource5
        '
        Me.ParcelDataBindingSource5.DataMember = "ParcelData"
        Me.ParcelDataBindingSource5.DataSource = Me.DeliverUS_DatabaseDataSet2
        '
        'ParcelDataTableAdapter2
        '
        Me.ParcelDataTableAdapter2.ClearBeforeFill = True
        '
        'DataGridViewTextBoxColumn8
        '
        Me.DataGridViewTextBoxColumn8.DataPropertyName = "TrackingNumber"
        Me.DataGridViewTextBoxColumn8.HeaderText = "TrackingNumber"
        Me.DataGridViewTextBoxColumn8.MinimumWidth = 8
        Me.DataGridViewTextBoxColumn8.Name = "DataGridViewTextBoxColumn8"
        Me.DataGridViewTextBoxColumn8.ReadOnly = True
        Me.DataGridViewTextBoxColumn8.Width = 150
        '
        'DataGridViewTextBoxColumn9
        '
        Me.DataGridViewTextBoxColumn9.DataPropertyName = "Size"
        Me.DataGridViewTextBoxColumn9.HeaderText = "Size"
        Me.DataGridViewTextBoxColumn9.MinimumWidth = 8
        Me.DataGridViewTextBoxColumn9.Name = "DataGridViewTextBoxColumn9"
        Me.DataGridViewTextBoxColumn9.ReadOnly = True
        Me.DataGridViewTextBoxColumn9.Width = 150
        '
        'DataGridViewTextBoxColumn10
        '
        Me.DataGridViewTextBoxColumn10.DataPropertyName = "CustomerID"
        Me.DataGridViewTextBoxColumn10.HeaderText = "CustomerID"
        Me.DataGridViewTextBoxColumn10.MinimumWidth = 8
        Me.DataGridViewTextBoxColumn10.Name = "DataGridViewTextBoxColumn10"
        Me.DataGridViewTextBoxColumn10.ReadOnly = True
        Me.DataGridViewTextBoxColumn10.Visible = False
        Me.DataGridViewTextBoxColumn10.Width = 150
        '
        'DataGridViewTextBoxColumn11
        '
        Me.DataGridViewTextBoxColumn11.DataPropertyName = "ArrivalDate"
        Me.DataGridViewTextBoxColumn11.HeaderText = "ArrivalDate"
        Me.DataGridViewTextBoxColumn11.MinimumWidth = 8
        Me.DataGridViewTextBoxColumn11.Name = "DataGridViewTextBoxColumn11"
        Me.DataGridViewTextBoxColumn11.ReadOnly = True
        Me.DataGridViewTextBoxColumn11.Width = 150
        '
        'DataGridViewTextBoxColumn12
        '
        Me.DataGridViewTextBoxColumn12.DataPropertyName = "DeliveryStatus"
        Me.DataGridViewTextBoxColumn12.HeaderText = "DeliveryStatus"
        Me.DataGridViewTextBoxColumn12.MinimumWidth = 8
        Me.DataGridViewTextBoxColumn12.Name = "DataGridViewTextBoxColumn12"
        Me.DataGridViewTextBoxColumn12.ReadOnly = True
        Me.DataGridViewTextBoxColumn12.Width = 150
        '
        'DataGridViewTextBoxColumn13
        '
        Me.DataGridViewTextBoxColumn13.DataPropertyName = "DeliveryTime"
        Me.DataGridViewTextBoxColumn13.HeaderText = "DeliveryTime"
        Me.DataGridViewTextBoxColumn13.MinimumWidth = 8
        Me.DataGridViewTextBoxColumn13.Name = "DataGridViewTextBoxColumn13"
        Me.DataGridViewTextBoxColumn13.ReadOnly = True
        Me.DataGridViewTextBoxColumn13.Width = 150
        '
        'CUSTOMER_Parcel_Status
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(9.0!, 20.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.MidnightBlue
        Me.ClientSize = New System.Drawing.Size(800, 881)
        Me.Controls.Add(Me.grdParcels)
        Me.Controls.Add(Me.btnBack)
        Me.Controls.Add(Me.btnAddParcel)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.btnTrack)
        Me.Controls.Add(Me.txtTracking)
        Me.Controls.Add(Me.lblTracking)
        Me.Controls.Add(Me.lblTrack)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "CUSTOMER_Parcel_Status"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Parcel Status"
        CType(Me.ParcelDataBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.ParcelDataBindingSource1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.ParcelDataBindingSource2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.grdParcels, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.ParcelDataBindingSource4, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.ParcelDataBindingSource3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.DeliverUS_DatabaseDataSet2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.ParcelDataBindingSource5, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents btnTrack As Button
    Friend WithEvents txtTracking As TextBox
    Friend WithEvents lblTracking As Label
    Friend WithEvents lblTrack As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents btnAddParcel As Button
    Friend WithEvents btnBack As Button
    Friend WithEvents DeliverUS_DatabaseDataSet As DeliverUS_DatabaseDataSet
    Friend WithEvents ParcelDataBindingSource As BindingSource
    Friend WithEvents ParcelDataTableAdapter As DeliverUS_DatabaseDataSetTableAdapters.ParcelDataTableAdapter
    Friend WithEvents TrackingNumberDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents ParcelDataBindingSource1 As BindingSource
    Friend WithEvents ParcelDataBindingSource2 As BindingSource
    Friend WithEvents grdParcels As DataGridView
    Friend WithEvents ParcelDataBindingSource3 As BindingSource
    Friend WithEvents DataGridViewTextBoxColumn1 As DataGridViewTextBoxColumn
    Friend WithEvents SizeDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents CustomerIDDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents ArrivalDateDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents DeliveryStatusDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents DeliveryTimeDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents PoPDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents DeliverUS_DatabaseDataSet1 As DeliverUS_DatabaseDataSet
    Friend WithEvents ParcelDataBindingSource4 As BindingSource
    Friend WithEvents ParcelDataTableAdapter1 As DeliverUS_DatabaseDataSetTableAdapters.ParcelDataTableAdapter
    Friend WithEvents DataGridViewTextBoxColumn2 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn3 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn4 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn5 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn6 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn7 As DataGridViewTextBoxColumn
    Friend WithEvents ProofOfPaymentDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents DeliverUS_DatabaseDataSet2 As DeliverUS_DatabaseDataSet
    Friend WithEvents ParcelDataBindingSource5 As BindingSource
    Friend WithEvents ParcelDataTableAdapter2 As DeliverUS_DatabaseDataSetTableAdapters.ParcelDataTableAdapter
    Friend WithEvents DataGridViewTextBoxColumn8 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn9 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn10 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn11 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn12 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn13 As DataGridViewTextBoxColumn
End Class
