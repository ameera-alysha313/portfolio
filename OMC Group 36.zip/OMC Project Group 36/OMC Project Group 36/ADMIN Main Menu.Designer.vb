﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class ADMIN_Main_Menu
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(ADMIN_Main_Menu))
        Me.btnLogOut = New System.Windows.Forms.Button()
        Me.btnFeedback = New System.Windows.Forms.Button()
        Me.btnCouriers = New System.Windows.Forms.Button()
        Me.btnCustomers = New System.Windows.Forms.Button()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.btnCustomerMenu = New System.Windows.Forms.Button()
        Me.btnCourierMenu = New System.Windows.Forms.Button()
        Me.btnExit = New System.Windows.Forms.Button()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'btnLogOut
        '
        Me.btnLogOut.BackColor = System.Drawing.Color.Orange
        Me.btnLogOut.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnLogOut.ForeColor = System.Drawing.Color.White
        Me.btnLogOut.Location = New System.Drawing.Point(219, 444)
        Me.btnLogOut.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.btnLogOut.Name = "btnLogOut"
        Me.btnLogOut.Size = New System.Drawing.Size(153, 56)
        Me.btnLogOut.TabIndex = 22
        Me.btnLogOut.Text = "Log Out"
        Me.btnLogOut.UseVisualStyleBackColor = False
        '
        'btnFeedback
        '
        Me.btnFeedback.BackColor = System.Drawing.Color.Orange
        Me.btnFeedback.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnFeedback.ForeColor = System.Drawing.Color.White
        Me.btnFeedback.Location = New System.Drawing.Point(624, 313)
        Me.btnFeedback.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.btnFeedback.Name = "btnFeedback"
        Me.btnFeedback.Size = New System.Drawing.Size(153, 56)
        Me.btnFeedback.TabIndex = 21
        Me.btnFeedback.Text = "Customer Feedback"
        Me.btnFeedback.UseVisualStyleBackColor = False
        '
        'btnCouriers
        '
        Me.btnCouriers.BackColor = System.Drawing.Color.Orange
        Me.btnCouriers.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnCouriers.ForeColor = System.Drawing.Color.White
        Me.btnCouriers.Location = New System.Drawing.Point(353, 313)
        Me.btnCouriers.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.btnCouriers.Name = "btnCouriers"
        Me.btnCouriers.Size = New System.Drawing.Size(153, 56)
        Me.btnCouriers.TabIndex = 20
        Me.btnCouriers.Text = "Courier List"
        Me.btnCouriers.UseVisualStyleBackColor = False
        '
        'btnCustomers
        '
        Me.btnCustomers.BackColor = System.Drawing.Color.Orange
        Me.btnCustomers.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnCustomers.ForeColor = System.Drawing.Color.White
        Me.btnCustomers.Location = New System.Drawing.Point(82, 313)
        Me.btnCustomers.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.btnCustomers.Name = "btnCustomers"
        Me.btnCustomers.Size = New System.Drawing.Size(153, 56)
        Me.btnCustomers.TabIndex = 19
        Me.btnCustomers.Text = "Customer List"
        Me.btnCustomers.UseVisualStyleBackColor = False
        '
        'PictureBox1
        '
        Me.PictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.PictureBox1.Image = Global.OMC_Project_Group_36.My.Resources.Resources.DeliverUS_Logo
        Me.PictureBox1.Location = New System.Drawing.Point(322, 73)
        Me.PictureBox1.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(234, 190)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox1.TabIndex = 24
        Me.PictureBox1.TabStop = False
        '
        'btnCustomerMenu
        '
        Me.btnCustomerMenu.BackColor = System.Drawing.Color.Orange
        Me.btnCustomerMenu.ForeColor = System.Drawing.Color.White
        Me.btnCustomerMenu.Location = New System.Drawing.Point(595, 46)
        Me.btnCustomerMenu.Name = "btnCustomerMenu"
        Me.btnCustomerMenu.Size = New System.Drawing.Size(206, 35)
        Me.btnCustomerMenu.TabIndex = 27
        Me.btnCustomerMenu.Text = "Switch to Customer Menu"
        Me.btnCustomerMenu.UseVisualStyleBackColor = False
        '
        'btnCourierMenu
        '
        Me.btnCourierMenu.BackColor = System.Drawing.Color.Orange
        Me.btnCourierMenu.ForeColor = System.Drawing.Color.White
        Me.btnCourierMenu.Location = New System.Drawing.Point(595, 87)
        Me.btnCourierMenu.Name = "btnCourierMenu"
        Me.btnCourierMenu.Size = New System.Drawing.Size(206, 35)
        Me.btnCourierMenu.TabIndex = 26
        Me.btnCourierMenu.Text = "Switch to Courier Menu"
        Me.btnCourierMenu.UseVisualStyleBackColor = False
        '
        'btnExit
        '
        Me.btnExit.BackColor = System.Drawing.Color.Orange
        Me.btnExit.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnExit.ForeColor = System.Drawing.Color.White
        Me.btnExit.Location = New System.Drawing.Point(487, 444)
        Me.btnExit.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Size = New System.Drawing.Size(153, 56)
        Me.btnExit.TabIndex = 28
        Me.btnExit.Text = "Exit"
        Me.btnExit.UseVisualStyleBackColor = False
        '
        'ADMIN_Main_Menu
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(9.0!, 20.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.MidnightBlue
        Me.ClientSize = New System.Drawing.Size(828, 585)
        Me.Controls.Add(Me.btnExit)
        Me.Controls.Add(Me.btnCustomerMenu)
        Me.Controls.Add(Me.btnCourierMenu)
        Me.Controls.Add(Me.PictureBox1)
        Me.Controls.Add(Me.btnLogOut)
        Me.Controls.Add(Me.btnFeedback)
        Me.Controls.Add(Me.btnCouriers)
        Me.Controls.Add(Me.btnCustomers)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "ADMIN_Main_Menu"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Main Menu"
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents btnLogOut As Button
    Friend WithEvents btnFeedback As Button
    Friend WithEvents btnCouriers As Button
    Friend WithEvents btnCustomers As Button
    Friend WithEvents btnCustomerMenu As Button
    Friend WithEvents btnCourierMenu As Button
    Friend WithEvents btnExit As Button
End Class
