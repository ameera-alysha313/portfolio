﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class ADMIN_Courier_List
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(ADMIN_Courier_List))
        Me.btnSearch = New System.Windows.Forms.Button()
        Me.cbSearchBy = New System.Windows.Forms.ComboBox()
        Me.txtSearch = New System.Windows.Forms.TextBox()
        Me.CourierDataBindingSource1 = New System.Windows.Forms.BindingSource(Me.components)
        Me.CourierDataBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.btnBack = New System.Windows.Forms.Button()
        Me.grdCourierList = New System.Windows.Forms.DataGridView()
        Me.CourierDataBindingSource3 = New System.Windows.Forms.BindingSource(Me.components)
        Me.CourierDataBindingSource2 = New System.Windows.Forms.BindingSource(Me.components)
        Me.DeliverUS_DatabaseDataSet3 = New OMC_Project_Group_36.DeliverUS_DatabaseDataSet()
        Me.CourierDataBindingSource4 = New System.Windows.Forms.BindingSource(Me.components)
        Me.CourierDataTableAdapter3 = New OMC_Project_Group_36.DeliverUS_DatabaseDataSetTableAdapters.CourierDataTableAdapter()
        Me.DataGridViewTextBoxColumn13 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn14 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn15 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn16 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn17 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn18 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewImageColumn3 = New System.Windows.Forms.DataGridViewImageColumn()
        Me.DataGridViewImageColumn4 = New System.Windows.Forms.DataGridViewImageColumn()
        CType(Me.CourierDataBindingSource1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.CourierDataBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.grdCourierList, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.CourierDataBindingSource3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.CourierDataBindingSource2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.DeliverUS_DatabaseDataSet3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.CourierDataBindingSource4, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'btnSearch
        '
        Me.btnSearch.BackColor = System.Drawing.Color.Orange
        Me.btnSearch.ForeColor = System.Drawing.Color.White
        Me.btnSearch.Location = New System.Drawing.Point(810, 91)
        Me.btnSearch.Name = "btnSearch"
        Me.btnSearch.Size = New System.Drawing.Size(149, 30)
        Me.btnSearch.TabIndex = 97
        Me.btnSearch.Text = "Search"
        Me.btnSearch.UseVisualStyleBackColor = False
        '
        'cbSearchBy
        '
        Me.cbSearchBy.FormattingEnabled = True
        Me.cbSearchBy.Items.AddRange(New Object() {"Student ID", "E-mail", "Name", "Phone"})
        Me.cbSearchBy.Location = New System.Drawing.Point(276, 89)
        Me.cbSearchBy.Name = "cbSearchBy"
        Me.cbSearchBy.Size = New System.Drawing.Size(134, 28)
        Me.cbSearchBy.TabIndex = 96
        Me.cbSearchBy.Text = "Student ID"
        '
        'txtSearch
        '
        Me.txtSearch.Location = New System.Drawing.Point(434, 91)
        Me.txtSearch.Name = "txtSearch"
        Me.txtSearch.Size = New System.Drawing.Size(350, 26)
        Me.txtSearch.TabIndex = 95
        '
        'CourierDataBindingSource1
        '
        Me.CourierDataBindingSource1.DataMember = "CourierData"
        '
        'CourierDataBindingSource
        '
        Me.CourierDataBindingSource.DataMember = "CourierData"
        '
        'btnBack
        '
        Me.btnBack.BackColor = System.Drawing.Color.Orange
        Me.btnBack.ForeColor = System.Drawing.Color.White
        Me.btnBack.Location = New System.Drawing.Point(33, 625)
        Me.btnBack.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.btnBack.Name = "btnBack"
        Me.btnBack.Size = New System.Drawing.Size(162, 51)
        Me.btnBack.TabIndex = 121
        Me.btnBack.Text = "Back"
        Me.btnBack.UseVisualStyleBackColor = False
        '
        'grdCourierList
        '
        Me.grdCourierList.AllowUserToAddRows = False
        Me.grdCourierList.AllowUserToDeleteRows = False
        Me.grdCourierList.AutoGenerateColumns = False
        Me.grdCourierList.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.grdCourierList.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.DataGridViewTextBoxColumn13, Me.DataGridViewTextBoxColumn14, Me.DataGridViewTextBoxColumn15, Me.DataGridViewTextBoxColumn16, Me.DataGridViewTextBoxColumn17, Me.DataGridViewTextBoxColumn18, Me.DataGridViewImageColumn3, Me.DataGridViewImageColumn4})
        Me.grdCourierList.DataSource = Me.CourierDataBindingSource4
        Me.grdCourierList.Location = New System.Drawing.Point(66, 178)
        Me.grdCourierList.MultiSelect = False
        Me.grdCourierList.Name = "grdCourierList"
        Me.grdCourierList.ReadOnly = True
        Me.grdCourierList.RowHeadersWidth = 62
        Me.grdCourierList.RowTemplate.Height = 28
        Me.grdCourierList.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.grdCourierList.Size = New System.Drawing.Size(1084, 393)
        Me.grdCourierList.TabIndex = 123
        '
        'CourierDataBindingSource2
        '
        Me.CourierDataBindingSource2.DataMember = "CourierData"
        '
        'DeliverUS_DatabaseDataSet3
        '
        Me.DeliverUS_DatabaseDataSet3.DataSetName = "DeliverUS_DatabaseDataSet"
        Me.DeliverUS_DatabaseDataSet3.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'CourierDataBindingSource4
        '
        Me.CourierDataBindingSource4.DataMember = "CourierData"
        Me.CourierDataBindingSource4.DataSource = Me.DeliverUS_DatabaseDataSet3
        '
        'CourierDataTableAdapter3
        '
        Me.CourierDataTableAdapter3.ClearBeforeFill = True
        '
        'DataGridViewTextBoxColumn13
        '
        Me.DataGridViewTextBoxColumn13.DataPropertyName = "StudentID"
        Me.DataGridViewTextBoxColumn13.HeaderText = "Student ID"
        Me.DataGridViewTextBoxColumn13.MinimumWidth = 8
        Me.DataGridViewTextBoxColumn13.Name = "DataGridViewTextBoxColumn13"
        Me.DataGridViewTextBoxColumn13.ReadOnly = True
        Me.DataGridViewTextBoxColumn13.Width = 150
        '
        'DataGridViewTextBoxColumn14
        '
        Me.DataGridViewTextBoxColumn14.DataPropertyName = "FullName"
        Me.DataGridViewTextBoxColumn14.HeaderText = "Name"
        Me.DataGridViewTextBoxColumn14.MinimumWidth = 8
        Me.DataGridViewTextBoxColumn14.Name = "DataGridViewTextBoxColumn14"
        Me.DataGridViewTextBoxColumn14.ReadOnly = True
        Me.DataGridViewTextBoxColumn14.Width = 150
        '
        'DataGridViewTextBoxColumn15
        '
        Me.DataGridViewTextBoxColumn15.DataPropertyName = "Email"
        Me.DataGridViewTextBoxColumn15.HeaderText = "Email"
        Me.DataGridViewTextBoxColumn15.MinimumWidth = 8
        Me.DataGridViewTextBoxColumn15.Name = "DataGridViewTextBoxColumn15"
        Me.DataGridViewTextBoxColumn15.ReadOnly = True
        Me.DataGridViewTextBoxColumn15.Width = 150
        '
        'DataGridViewTextBoxColumn16
        '
        Me.DataGridViewTextBoxColumn16.DataPropertyName = "Phone"
        Me.DataGridViewTextBoxColumn16.HeaderText = "Phone"
        Me.DataGridViewTextBoxColumn16.MinimumWidth = 8
        Me.DataGridViewTextBoxColumn16.Name = "DataGridViewTextBoxColumn16"
        Me.DataGridViewTextBoxColumn16.ReadOnly = True
        Me.DataGridViewTextBoxColumn16.Width = 150
        '
        'DataGridViewTextBoxColumn17
        '
        Me.DataGridViewTextBoxColumn17.DataPropertyName = "Gender"
        Me.DataGridViewTextBoxColumn17.HeaderText = "Gender"
        Me.DataGridViewTextBoxColumn17.MinimumWidth = 8
        Me.DataGridViewTextBoxColumn17.Name = "DataGridViewTextBoxColumn17"
        Me.DataGridViewTextBoxColumn17.ReadOnly = True
        Me.DataGridViewTextBoxColumn17.Width = 150
        '
        'DataGridViewTextBoxColumn18
        '
        Me.DataGridViewTextBoxColumn18.DataPropertyName = "RegistrationDate"
        Me.DataGridViewTextBoxColumn18.HeaderText = "Registration Date"
        Me.DataGridViewTextBoxColumn18.MinimumWidth = 8
        Me.DataGridViewTextBoxColumn18.Name = "DataGridViewTextBoxColumn18"
        Me.DataGridViewTextBoxColumn18.ReadOnly = True
        Me.DataGridViewTextBoxColumn18.Width = 150
        '
        'DataGridViewImageColumn3
        '
        Me.DataGridViewImageColumn3.DataPropertyName = "StudentCard"
        Me.DataGridViewImageColumn3.HeaderText = "Student Card"
        Me.DataGridViewImageColumn3.MinimumWidth = 8
        Me.DataGridViewImageColumn3.Name = "DataGridViewImageColumn3"
        Me.DataGridViewImageColumn3.ReadOnly = True
        Me.DataGridViewImageColumn3.Visible = False
        Me.DataGridViewImageColumn3.Width = 150
        '
        'DataGridViewImageColumn4
        '
        Me.DataGridViewImageColumn4.DataPropertyName = "License"
        Me.DataGridViewImageColumn4.HeaderText = "License"
        Me.DataGridViewImageColumn4.MinimumWidth = 8
        Me.DataGridViewImageColumn4.Name = "DataGridViewImageColumn4"
        Me.DataGridViewImageColumn4.ReadOnly = True
        Me.DataGridViewImageColumn4.Visible = False
        Me.DataGridViewImageColumn4.Width = 150
        '
        'ADMIN_Courier_List
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(10.0!, 20.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.MidnightBlue
        Me.ClientSize = New System.Drawing.Size(1216, 725)
        Me.Controls.Add(Me.btnBack)
        Me.Controls.Add(Me.btnSearch)
        Me.Controls.Add(Me.cbSearchBy)
        Me.Controls.Add(Me.txtSearch)
        Me.Controls.Add(Me.grdCourierList)
        Me.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "ADMIN_Courier_List"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Courier List"
        CType(Me.CourierDataBindingSource1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.CourierDataBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.grdCourierList, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.CourierDataBindingSource3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.CourierDataBindingSource2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.DeliverUS_DatabaseDataSet3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.CourierDataBindingSource4, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents btnSearch As Button
    Friend WithEvents cbSearchBy As ComboBox
    Friend WithEvents txtSearch As TextBox
    Friend WithEvents DeliverUS_DatabaseDataSet As DeliverUS_DatabaseDataSet
    Friend WithEvents CourierDataBindingSource As BindingSource
    Friend WithEvents CourierDataTableAdapter As DeliverUS_DatabaseDataSetTableAdapters.CourierDataTableAdapter
    Friend WithEvents CourierDataBindingSource1 As BindingSource
    Friend WithEvents btnBack As Button
    Friend WithEvents grdCourierList As DataGridView
    Friend WithEvents StudentIDDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents FullNameDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents EmailDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents PhoneDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents GenderDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents RegistrationDateDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents StudentCardDataGridViewTextBoxColumn As DataGridViewImageColumn
    Friend WithEvents LicenseDataGridViewTextBoxColumn As DataGridViewImageColumn
    Friend WithEvents DeliverUS_DatabaseDataSet1 As DeliverUS_DatabaseDataSet
    Friend WithEvents CourierDataBindingSource2 As BindingSource
    Friend WithEvents CourierDataTableAdapter1 As DeliverUS_DatabaseDataSetTableAdapters.CourierDataTableAdapter
    Friend WithEvents DataGridViewTextBoxColumn1 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn2 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn3 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn4 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn5 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn6 As DataGridViewTextBoxColumn
    Friend WithEvents StudentCardDataGridViewImageColumn As DataGridViewImageColumn
    Friend WithEvents LicenseDataGridViewImageColumn As DataGridViewImageColumn
    Friend WithEvents DeliverUS_DatabaseDataSet2 As DeliverUS_DatabaseDataSet
    Friend WithEvents CourierDataBindingSource3 As BindingSource
    Friend WithEvents CourierDataTableAdapter2 As DeliverUS_DatabaseDataSetTableAdapters.CourierDataTableAdapter
    Friend WithEvents DataGridViewTextBoxColumn7 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn8 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn9 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn10 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn11 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn12 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewImageColumn1 As DataGridViewImageColumn
    Friend WithEvents DataGridViewImageColumn2 As DataGridViewImageColumn
    Friend WithEvents DeliverUS_DatabaseDataSet3 As DeliverUS_DatabaseDataSet
    Friend WithEvents CourierDataBindingSource4 As BindingSource
    Friend WithEvents CourierDataTableAdapter3 As DeliverUS_DatabaseDataSetTableAdapters.CourierDataTableAdapter
    Friend WithEvents DataGridViewTextBoxColumn13 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn14 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn15 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn16 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn17 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn18 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewImageColumn3 As DataGridViewImageColumn
    Friend WithEvents DataGridViewImageColumn4 As DataGridViewImageColumn
End Class
