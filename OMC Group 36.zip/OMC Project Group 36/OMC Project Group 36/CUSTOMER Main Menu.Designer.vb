﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class CUSTOMER_Main_Menu
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(CUSTOMER_Main_Menu))
        Me.btnLogOut = New System.Windows.Forms.Button()
        Me.btnExit = New System.Windows.Forms.Button()
        Me.btnCheckParcel = New System.Windows.Forms.Button()
        Me.btnUserProfile = New System.Windows.Forms.Button()
        Me.btnCourierMenu = New System.Windows.Forms.Button()
        Me.btnAdminMenu = New System.Windows.Forms.Button()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'btnLogOut
        '
        Me.btnLogOut.BackColor = System.Drawing.Color.Orange
        Me.btnLogOut.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnLogOut.ForeColor = System.Drawing.Color.White
        Me.btnLogOut.Location = New System.Drawing.Point(240, 489)
        Me.btnLogOut.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.btnLogOut.Name = "btnLogOut"
        Me.btnLogOut.Size = New System.Drawing.Size(153, 56)
        Me.btnLogOut.TabIndex = 11
        Me.btnLogOut.Text = "Log Out"
        Me.btnLogOut.UseVisualStyleBackColor = False
        '
        'btnExit
        '
        Me.btnExit.BackColor = System.Drawing.Color.Orange
        Me.btnExit.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnExit.ForeColor = System.Drawing.Color.White
        Me.btnExit.Location = New System.Drawing.Point(502, 489)
        Me.btnExit.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Size = New System.Drawing.Size(153, 56)
        Me.btnExit.TabIndex = 10
        Me.btnExit.Text = "Exit"
        Me.btnExit.UseVisualStyleBackColor = False
        '
        'btnCheckParcel
        '
        Me.btnCheckParcel.BackColor = System.Drawing.Color.Orange
        Me.btnCheckParcel.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnCheckParcel.ForeColor = System.Drawing.Color.White
        Me.btnCheckParcel.Location = New System.Drawing.Point(240, 372)
        Me.btnCheckParcel.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.btnCheckParcel.Name = "btnCheckParcel"
        Me.btnCheckParcel.Size = New System.Drawing.Size(153, 56)
        Me.btnCheckParcel.TabIndex = 8
        Me.btnCheckParcel.Text = "Check Parcel"
        Me.btnCheckParcel.UseVisualStyleBackColor = False
        '
        'btnUserProfile
        '
        Me.btnUserProfile.BackColor = System.Drawing.Color.Orange
        Me.btnUserProfile.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnUserProfile.ForeColor = System.Drawing.Color.White
        Me.btnUserProfile.Location = New System.Drawing.Point(502, 372)
        Me.btnUserProfile.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.btnUserProfile.Name = "btnUserProfile"
        Me.btnUserProfile.Size = New System.Drawing.Size(153, 56)
        Me.btnUserProfile.TabIndex = 7
        Me.btnUserProfile.Text = "View Profile"
        Me.btnUserProfile.UseVisualStyleBackColor = False
        '
        'btnCourierMenu
        '
        Me.btnCourierMenu.BackColor = System.Drawing.Color.Orange
        Me.btnCourierMenu.ForeColor = System.Drawing.Color.White
        Me.btnCourierMenu.Location = New System.Drawing.Point(650, 47)
        Me.btnCourierMenu.Name = "btnCourierMenu"
        Me.btnCourierMenu.Size = New System.Drawing.Size(191, 35)
        Me.btnCourierMenu.TabIndex = 14
        Me.btnCourierMenu.Text = "Switch to Courier Menu"
        Me.btnCourierMenu.UseVisualStyleBackColor = False
        Me.btnCourierMenu.Visible = False
        '
        'btnAdminMenu
        '
        Me.btnAdminMenu.BackColor = System.Drawing.Color.Orange
        Me.btnAdminMenu.ForeColor = System.Drawing.Color.White
        Me.btnAdminMenu.Location = New System.Drawing.Point(650, 88)
        Me.btnAdminMenu.Name = "btnAdminMenu"
        Me.btnAdminMenu.Size = New System.Drawing.Size(191, 35)
        Me.btnAdminMenu.TabIndex = 15
        Me.btnAdminMenu.Text = "Switch to Admin Menu"
        Me.btnAdminMenu.UseVisualStyleBackColor = False
        Me.btnAdminMenu.Visible = False
        '
        'PictureBox1
        '
        Me.PictureBox1.BackColor = System.Drawing.Color.Transparent
        Me.PictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.PictureBox1.Image = Global.OMC_Project_Group_36.My.Resources.Resources.DeliverUS_Logo
        Me.PictureBox1.Location = New System.Drawing.Point(313, 106)
        Me.PictureBox1.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(234, 190)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox1.TabIndex = 12
        Me.PictureBox1.TabStop = False
        '
        'CUSTOMER_Main_Menu
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(9.0!, 20.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.MidnightBlue
        Me.ClientSize = New System.Drawing.Size(874, 648)
        Me.Controls.Add(Me.btnAdminMenu)
        Me.Controls.Add(Me.PictureBox1)
        Me.Controls.Add(Me.btnLogOut)
        Me.Controls.Add(Me.btnExit)
        Me.Controls.Add(Me.btnCheckParcel)
        Me.Controls.Add(Me.btnUserProfile)
        Me.Controls.Add(Me.btnCourierMenu)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.Name = "CUSTOMER_Main_Menu"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Main Menu"
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents btnLogOut As Button
    Friend WithEvents btnExit As Button
    Friend WithEvents btnCheckParcel As Button
    Friend WithEvents btnUserProfile As Button
    Friend WithEvents btnCourierMenu As Button
    Friend WithEvents btnAdminMenu As Button
End Class
