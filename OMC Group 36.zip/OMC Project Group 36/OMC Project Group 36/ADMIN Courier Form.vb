﻿Public Class ADMIN_Courier_Form
    Sub FormUpdate()
        txtName.Text = ADMIN_Courier_List.grdCourierList.CurrentRow.Cells(1).Value.ToString
        txtGender.Text = ADMIN_Courier_List.grdCourierList.CurrentRow.Cells(4).Value.ToString
        txtPhone.Text = ADMIN_Courier_List.grdCourierList.CurrentRow.Cells(3).Value.ToString
        txtStudentID.Text = ADMIN_Courier_List.grdCourierList.CurrentRow.Cells(0).Value.ToString
        txtEmail.Text = ADMIN_Courier_List.grdCourierList.CurrentRow.Cells(2).Value.ToString
        txtRegistrationDate.Text = ADMIN_Courier_List.grdCourierList.CurrentRow.Cells(5).Value
    End Sub

    Private Sub btnPrev_Click(sender As Object, e As EventArgs) Handles btnPrev.Click
        ADMIN_Customer_List.UserDataBindingSource.MovePrevious()
        FormUpdate()
    End Sub

    Private Sub btnNext_Click(sender As Object, e As EventArgs) Handles btnNext.Click
        ADMIN_Customer_List.UserDataBindingSource.MoveNext()
        FormUpdate()
    End Sub

    Private Sub ADMIN_Courier_Form_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub
End Class