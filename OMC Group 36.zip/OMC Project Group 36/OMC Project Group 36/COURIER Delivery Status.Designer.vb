﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class COURIER_Delivery_Status
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(COURIER_Delivery_Status))
        Me.grdCourierList = New System.Windows.Forms.DataGridView()
        Me.ParcelDataBindingSource1 = New System.Windows.Forms.BindingSource(Me.components)
        Me.btnBack = New System.Windows.Forms.Button()
        Me.ParcelDataBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.DeliverUS_DatabaseDataSet5 = New OMC_Project_Group_36.DeliverUS_DatabaseDataSet()
        Me.ParcelDataBindingSource2 = New System.Windows.Forms.BindingSource(Me.components)
        Me.ParcelDataTableAdapter5 = New OMC_Project_Group_36.DeliverUS_DatabaseDataSetTableAdapters.ParcelDataTableAdapter()
        Me.DataGridViewTextBoxColumn29 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn30 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn31 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn32 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn33 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn34 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn35 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        CType(Me.grdCourierList, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.ParcelDataBindingSource1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.ParcelDataBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.DeliverUS_DatabaseDataSet5, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.ParcelDataBindingSource2, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'grdCourierList
        '
        Me.grdCourierList.AllowUserToAddRows = False
        Me.grdCourierList.AllowUserToDeleteRows = False
        Me.grdCourierList.AutoGenerateColumns = False
        Me.grdCourierList.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.grdCourierList.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.DataGridViewTextBoxColumn29, Me.DataGridViewTextBoxColumn30, Me.DataGridViewTextBoxColumn31, Me.DataGridViewTextBoxColumn32, Me.DataGridViewTextBoxColumn33, Me.DataGridViewTextBoxColumn34, Me.DataGridViewTextBoxColumn35})
        Me.grdCourierList.DataSource = Me.ParcelDataBindingSource2
        Me.grdCourierList.Location = New System.Drawing.Point(32, 240)
        Me.grdCourierList.Name = "grdCourierList"
        Me.grdCourierList.ReadOnly = True
        Me.grdCourierList.RowHeadersWidth = 62
        Me.grdCourierList.RowTemplate.Height = 28
        Me.grdCourierList.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.grdCourierList.Size = New System.Drawing.Size(998, 371)
        Me.grdCourierList.TabIndex = 0
        '
        'ParcelDataBindingSource1
        '
        Me.ParcelDataBindingSource1.DataMember = "ParcelData"
        '
        'btnBack
        '
        Me.btnBack.BackColor = System.Drawing.Color.Orange
        Me.btnBack.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnBack.ForeColor = System.Drawing.Color.White
        Me.btnBack.Location = New System.Drawing.Point(32, 639)
        Me.btnBack.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.btnBack.Name = "btnBack"
        Me.btnBack.Size = New System.Drawing.Size(146, 51)
        Me.btnBack.TabIndex = 122
        Me.btnBack.Text = "Back"
        Me.btnBack.UseVisualStyleBackColor = False
        '
        'ParcelDataBindingSource
        '
        Me.ParcelDataBindingSource.DataMember = "ParcelData"
        '
        'DeliverUS_DatabaseDataSet5
        '
        Me.DeliverUS_DatabaseDataSet5.DataSetName = "DeliverUS_DatabaseDataSet"
        Me.DeliverUS_DatabaseDataSet5.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'ParcelDataBindingSource2
        '
        Me.ParcelDataBindingSource2.DataMember = "ParcelData"
        Me.ParcelDataBindingSource2.DataSource = Me.DeliverUS_DatabaseDataSet5
        '
        'ParcelDataTableAdapter5
        '
        Me.ParcelDataTableAdapter5.ClearBeforeFill = True
        '
        'DataGridViewTextBoxColumn29
        '
        Me.DataGridViewTextBoxColumn29.DataPropertyName = "TrackingNumber"
        Me.DataGridViewTextBoxColumn29.HeaderText = "TrackingNumber"
        Me.DataGridViewTextBoxColumn29.MinimumWidth = 8
        Me.DataGridViewTextBoxColumn29.Name = "DataGridViewTextBoxColumn29"
        Me.DataGridViewTextBoxColumn29.ReadOnly = True
        Me.DataGridViewTextBoxColumn29.Width = 150
        '
        'DataGridViewTextBoxColumn30
        '
        Me.DataGridViewTextBoxColumn30.DataPropertyName = "Size"
        Me.DataGridViewTextBoxColumn30.HeaderText = "Size"
        Me.DataGridViewTextBoxColumn30.MinimumWidth = 8
        Me.DataGridViewTextBoxColumn30.Name = "DataGridViewTextBoxColumn30"
        Me.DataGridViewTextBoxColumn30.ReadOnly = True
        Me.DataGridViewTextBoxColumn30.Width = 150
        '
        'DataGridViewTextBoxColumn31
        '
        Me.DataGridViewTextBoxColumn31.DataPropertyName = "CustomerID"
        Me.DataGridViewTextBoxColumn31.HeaderText = "CustomerID"
        Me.DataGridViewTextBoxColumn31.MinimumWidth = 8
        Me.DataGridViewTextBoxColumn31.Name = "DataGridViewTextBoxColumn31"
        Me.DataGridViewTextBoxColumn31.ReadOnly = True
        Me.DataGridViewTextBoxColumn31.Width = 150
        '
        'DataGridViewTextBoxColumn32
        '
        Me.DataGridViewTextBoxColumn32.DataPropertyName = "ArrivalDate"
        Me.DataGridViewTextBoxColumn32.HeaderText = "ArrivalDate"
        Me.DataGridViewTextBoxColumn32.MinimumWidth = 8
        Me.DataGridViewTextBoxColumn32.Name = "DataGridViewTextBoxColumn32"
        Me.DataGridViewTextBoxColumn32.ReadOnly = True
        Me.DataGridViewTextBoxColumn32.Width = 150
        '
        'DataGridViewTextBoxColumn33
        '
        Me.DataGridViewTextBoxColumn33.DataPropertyName = "DeliveryStatus"
        Me.DataGridViewTextBoxColumn33.HeaderText = "DeliveryStatus"
        Me.DataGridViewTextBoxColumn33.MinimumWidth = 8
        Me.DataGridViewTextBoxColumn33.Name = "DataGridViewTextBoxColumn33"
        Me.DataGridViewTextBoxColumn33.ReadOnly = True
        Me.DataGridViewTextBoxColumn33.Width = 150
        '
        'DataGridViewTextBoxColumn34
        '
        Me.DataGridViewTextBoxColumn34.DataPropertyName = "DeliveryTime"
        Me.DataGridViewTextBoxColumn34.HeaderText = "DeliveryTime"
        Me.DataGridViewTextBoxColumn34.MinimumWidth = 8
        Me.DataGridViewTextBoxColumn34.Name = "DataGridViewTextBoxColumn34"
        Me.DataGridViewTextBoxColumn34.ReadOnly = True
        Me.DataGridViewTextBoxColumn34.Width = 150
        '
        'DataGridViewTextBoxColumn35
        '
        Me.DataGridViewTextBoxColumn35.DataPropertyName = "CourierID"
        Me.DataGridViewTextBoxColumn35.HeaderText = "CourierID"
        Me.DataGridViewTextBoxColumn35.MinimumWidth = 8
        Me.DataGridViewTextBoxColumn35.Name = "DataGridViewTextBoxColumn35"
        Me.DataGridViewTextBoxColumn35.ReadOnly = True
        Me.DataGridViewTextBoxColumn35.Visible = False
        Me.DataGridViewTextBoxColumn35.Width = 150
        '
        'COURIER_Delivery_Status
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(9.0!, 20.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.MidnightBlue
        Me.ClientSize = New System.Drawing.Size(1101, 720)
        Me.Controls.Add(Me.btnBack)
        Me.Controls.Add(Me.grdCourierList)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "COURIER_Delivery_Status"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Deliveries"
        CType(Me.grdCourierList, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.ParcelDataBindingSource1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.ParcelDataBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.DeliverUS_DatabaseDataSet5, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.ParcelDataBindingSource2, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents grdCourierList As DataGridView
    Friend WithEvents DeliverUS_DatabaseDataSet As DeliverUS_DatabaseDataSet
    Friend WithEvents ParcelDataTableAdapter As DeliverUS_DatabaseDataSetTableAdapters.ParcelDataTableAdapter
    Friend WithEvents TrackingNumberDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents SizeDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents CustomerIDDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents ArrivalDateDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents DeliveryStatusDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents DeliveryTimeDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents CourierIDDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents btnBack As Button
    Friend WithEvents DeliverUS_DatabaseDataSet1 As DeliverUS_DatabaseDataSet
    Friend WithEvents ParcelDataTableAdapter1 As DeliverUS_DatabaseDataSetTableAdapters.ParcelDataTableAdapter
    Friend WithEvents DataGridViewTextBoxColumn1 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn2 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn3 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn4 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn5 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn6 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn7 As DataGridViewTextBoxColumn
    Friend WithEvents DeliverUS_DatabaseDataSet2 As DeliverUS_DatabaseDataSet
    Friend WithEvents ParcelDataTableAdapter2 As DeliverUS_DatabaseDataSetTableAdapters.ParcelDataTableAdapter
    Friend WithEvents DataGridViewTextBoxColumn8 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn9 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn10 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn11 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn12 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn13 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn14 As DataGridViewTextBoxColumn
    Friend WithEvents ProofOfPaymentDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents DeliverUS_DatabaseDataSet3 As DeliverUS_DatabaseDataSet
    Friend WithEvents ParcelDataTableAdapter3 As DeliverUS_DatabaseDataSetTableAdapters.ParcelDataTableAdapter
    Friend WithEvents DataGridViewTextBoxColumn15 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn16 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn17 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn18 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn19 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn20 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn21 As DataGridViewTextBoxColumn
    Friend WithEvents DeliverUS_DatabaseDataSet4 As DeliverUS_DatabaseDataSet
    Friend WithEvents ParcelDataBindingSource As BindingSource
    Friend WithEvents ParcelDataTableAdapter4 As DeliverUS_DatabaseDataSetTableAdapters.ParcelDataTableAdapter
    Friend WithEvents DataGridViewTextBoxColumn22 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn23 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn24 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn25 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn26 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn27 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn28 As DataGridViewTextBoxColumn
    Friend WithEvents ParcelDataBindingSource1 As BindingSource
    Friend WithEvents DeliverUS_DatabaseDataSet5 As DeliverUS_DatabaseDataSet
    Friend WithEvents ParcelDataBindingSource2 As BindingSource
    Friend WithEvents ParcelDataTableAdapter5 As DeliverUS_DatabaseDataSetTableAdapters.ParcelDataTableAdapter
    Friend WithEvents DataGridViewTextBoxColumn29 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn30 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn31 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn32 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn33 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn34 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn35 As DataGridViewTextBoxColumn
End Class
