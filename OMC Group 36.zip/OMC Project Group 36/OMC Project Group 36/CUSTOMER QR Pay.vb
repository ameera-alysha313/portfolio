﻿Imports System.Security.Cryptography

Public Class CUSTOMER_QR_Pay


    Private Sub btnCancel_Click(sender As Object, e As EventArgs) Handles btnCancel.Click
        Me.Close()
        CUSTOMER_Method_Of_Payment.Show()
    End Sub



    Private Sub btnSubmit_Click(sender As Object, e As EventArgs) Handles btnSubmit.Click
        Me.Close()
        CUSTOMER_Method_Of_Payment.Close()
    End Sub
End Class