﻿Imports System.Data.OleDb

Public Class CUSTOMER_Feedback_Form
    Dim conn As New OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" & Application.StartupPath & "\DeliverUS_Database.accdb")
    Dim cmd As OleDbCommand
    Dim dt As New DataTable
    Dim da As New OleDbDataAdapter(cmd)
    Dim dr As OleDbDataReader
    Dim rating As Integer
    Dim review As String

    Private Sub btn1Star_Click(sender As Object, e As EventArgs) Handles btn1Star.Click
        btn1Star.Image = My.Resources.starfill
        btn2Star.Image = My.Resources.star
        btn3Star.Image = My.Resources.star
        btn4Star.Image = My.Resources.star
        btn5Star.Image = My.Resources.star
    End Sub

    Private Sub btn2Star_Click(sender As Object, e As EventArgs) Handles btn2Star.Click
        btn1Star.Image = My.Resources.starfill
        btn2Star.Image = My.Resources.starfill
        btn3Star.Image = My.Resources.star
        btn4Star.Image = My.Resources.star
        btn5Star.Image = My.Resources.star
    End Sub

    Private Sub btn3Star_Click(sender As Object, e As EventArgs) Handles btn3Star.Click
        btn1Star.Image = My.Resources.starfill
        btn2Star.Image = My.Resources.starfill
        btn3Star.Image = My.Resources.starfill
        btn4Star.Image = My.Resources.star
        btn5Star.Image = My.Resources.star
    End Sub

    Private Sub btn4Star_Click(sender As Object, e As EventArgs) Handles btn4Star.Click
        btn1Star.Image = My.Resources.starfill
        btn2Star.Image = My.Resources.starfill
        btn3Star.Image = My.Resources.starfill
        btn4Star.Image = My.Resources.starfill
        btn5Star.Image = My.Resources.star
    End Sub

    Private Sub btn5Star_Click(sender As Object, e As EventArgs) Handles btn5Star.Click
        btn1Star.Image = My.Resources.starfill
        btn2Star.Image = My.Resources.starfill
        btn3Star.Image = My.Resources.starfill
        btn4Star.Image = My.Resources.starfill
        btn5Star.Image = My.Resources.starfill
    End Sub

    Private Sub txtReview_Click(sender As Object, e As EventArgs) Handles txtReview.Click
        If (txtReview.Text).ToUpper = "PLEASE ENTER YOUR REVIEW" Then
            txtReview.Text = ""
        End If
    End Sub

    Private Sub btnSend_Click(sender As Object, e As EventArgs) Handles btnSend.Click


        If (txtReview.Text).ToUpper = "PLEASE ENTER YOUR REVIEW" Then
            txtReview.Text = ""
        End If

        review = txtReview.Text

        ' Value assigned to rating is based on stars filled
        If btn5Star.Image Is My.Resources.starfill Then
            rating = 5

        ElseIf btn4Star.Image Is My.Resources.starfill Then
            rating = 4

        ElseIf btn3Star.Image Is My.Resources.starfill Then
            rating = 3

        ElseIf btn2Star.Image Is My.Resources.starfill Then
            rating = 2

        ElseIf btn1Star.Image Is My.Resources.starfill Then
            rating = 1

        End If


        Dim cmd As New OleDbCommand("insert into ReviewData(`StudentID`,`Review`,`Rating`) values(@StudentID,@Review,@Rating)", conn)

        conn.Open()

        cmd.Parameters.Clear()
        cmd.Parameters.AddWithValue("@StudentID", StudentID)
        cmd.Parameters.AddWithValue("@Review", txtReview.Text)
        cmd.Parameters.AddWithValue("@Rating", rating)

        If cmd.ExecuteNonQuery > 0 Then

            MsgBox("Review sent!", vbInformation)

            Me.Close()

            rating = 0
            txtReview.Clear()

        End If



    End Sub

    Private Sub btnCancel_Click(sender As Object, e As EventArgs) Handles btnCancel.Click
        Me.Close()
    End Sub

End Class