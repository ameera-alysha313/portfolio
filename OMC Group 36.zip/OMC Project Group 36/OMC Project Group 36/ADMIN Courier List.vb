﻿Imports System.Data.OleDb
Imports System.IO

Public Class ADMIN_Courier_List

    Dim conn As New OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" & Application.StartupPath & "\DeliverUS_Database.accdb")
    Dim cmd As OleDbCommand
    Dim dt As New DataTable
    Dim da As New OleDbDataAdapter(cmd)

    Private Sub ADMIN_Courier_List_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'DeliverUS_DatabaseDataSet3.CourierData' table. You can move, or remove it, as needed.
        Me.CourierDataTableAdapter3.Fill(Me.DeliverUS_DatabaseDataSet3.CourierData)


    End Sub

    Private Sub grdCourierList_CellContentClick_1(sender As Object, e As DataGridViewCellEventArgs) Handles grdCourierList.CellContentClick
        ADMIN_Courier_Form.Show()

        ADMIN_Courier_Form.txtName.Text = grdCourierList.CurrentRow.Cells(1).Value.ToString
        ADMIN_Courier_Form.txtGender.Text = grdCourierList.CurrentRow.Cells(4).Value.ToString
        ADMIN_Courier_Form.txtPhone.Text = grdCourierList.CurrentRow.Cells(3).Value.ToString
        ADMIN_Courier_Form.txtStudentID.Text = grdCourierList.CurrentRow.Cells(0).Value.ToString
        ADMIN_Courier_Form.txtEmail.Text = grdCourierList.CurrentRow.Cells(2).Value.ToString
        ADMIN_Courier_Form.txtRegistrationDate.Text = grdCourierList.CurrentRow.Cells(5).Value

        Dim bytes As Byte() = grdCourierList.CurrentRow.Cells(6).Value
        Using ms As New MemoryStream(bytes)
            ADMIN_Courier_Form.picStudentCard.Image = Image.FromStream(ms)
        End Using

        Dim bytes1 As Byte() = grdCourierList.CurrentRow.Cells(7).Value
        Using ms As New MemoryStream(bytes1)
            ADMIN_Courier_Form.picLicense.Image = Image.FromStream(ms)
        End Using


    End Sub


    Private Sub txtSearch_Enter(sender As Object, e As EventArgs) Handles txtSearch.Enter

        'Auto fill for search box

        Dim dr As OleDbDataReader
        Dim ds As New DataSet
        Dim searchBy As String


        If cbSearchBy.Text = "Student ID" Then
            searchBy = "StudentID"

        ElseIf cbSearchBy.Text = "E-mail" Then
            searchBy = "Email"

        ElseIf cbSearchBy.Text = "Name" Then
            searchBy = "FullName"

        ElseIf cbSearchBy.Text = "Phone" Then
            searchBy = "Phone"

        End If

        Dim cmd As New OleDbCommand("Select " & searchBy & " from CourierData Order by StudentId Asc", conn)
        Dim autoComp As New AutoCompleteStringCollection()

        conn.Open()

        dr = cmd.ExecuteReader

        While dr.Read()
            autoComp.Add(dr(searchBy))
        End While

        txtSearch.AutoCompleteMode = AutoCompleteMode.Suggest
        txtSearch.AutoCompleteSource = AutoCompleteSource.CustomSource
        txtSearch.AutoCompleteCustomSource = autoComp

        conn.Close()

    End Sub
    Private Sub btnSearch_Click(sender As Object, e As EventArgs) Handles btnSearch.Click
        Dim temp As Integer = 0
        Dim colIndex As Integer


        grdCourierList.CurrentRow.Selected = False

        If cbSearchBy.Text = "Student ID" Then
            colIndex = 0

        ElseIf cbSearchBy.Text = "E-mail" Then
            colIndex = 2

        ElseIf cbSearchBy.Text = "Name" Then
            colIndex = 1

        ElseIf cbSearchBy.Text = "Phone" Then
            colIndex = 3

        End If

        For i As Integer = 0 To grdCourierList.RowCount - 1

            If grdCourierList.Rows(i).Cells(colIndex).Value.ToString = txtSearch.Text Then
                grdCourierList.Rows(i).Selected = True
                MsgBox("User found")
                temp = 1
            End If

        Next

        If temp = 0 Then
            MsgBox("User not found")
        End If

    End Sub


    Private Sub btnBack_Click(sender As Object, e As EventArgs) Handles btnBack.Click
        Me.Close()
        ADMIN_Main_Menu.Show()
    End Sub

    Private Sub ADMIN_Courier_List_FormClosed(sender As Object, e As FormClosedEventArgs) Handles MyBase.FormClosed
        ADMIN_Main_Menu.Show()
    End Sub

End Class