﻿Imports System.Data.OleDb

Public Class ADMIN_Main_Menu

    Dim conn As New OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" & Application.StartupPath & "\DeliverUS_Database.accdb")
    Dim cmd As OleDbCommand
    Dim dt As New DataTable
    Dim da As New OleDbDataAdapter(cmd)


    Public Sub ADMIN_Main_Menu_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        Dim dr As OleDbDataReader

        conn.Open()
        Dim cmd As New OleDbCommand("select*from AdminData where StudentID=@StudentID", conn)
        cmd.Parameters.Clear()
        cmd.Parameters.AddWithValue("@StudentID", StudentID)

        dr = cmd.ExecuteReader

        If dr.Read() = True Then
            btnCourierMenu.Show()
        End If
        conn.Close()

    End Sub

    ' Admin has can switch between customer and admin menu 
    Private Sub btnCustomerMenu_Click(sender As Object, e As EventArgs) Handles btnCustomerMenu.Click
        Me.Hide()
        CUSTOMER_Main_Menu.Show()
    End Sub


    ' Button only appears when admin is also registered as a courier
    Private Sub btnCourierMenu_Click(sender As Object, e As EventArgs) Handles btnCourierMenu.Click
        Me.Hide()
        COURIER_Main_Menu.Show()
    End Sub

    Private Sub btnCustomers_Click(sender As Object, e As EventArgs) Handles btnCustomers.Click
        Me.Hide()
        ADMIN_Customer_List.Show()
    End Sub

    Private Sub btnCouriers_Click(sender As Object, e As EventArgs) Handles btnCouriers.Click
        Me.Hide()
        ADMIN_Courier_List.Show()
    End Sub


    Private Sub btnFeedback_Click(sender As Object, e As EventArgs) Handles btnFeedback.Click
        Me.Hide()
        ADMIN_Review_List.Show()
    End Sub

    Private Sub btnLogOut_Click(sender As Object, e As EventArgs) Handles btnLogOut.Click
        Dim result As Integer
        result = MsgBox("Are you sure you want to log out?", vbYesNo + vbExclamation, "Logging out...")

        If result = vbYes Then
            StudentID = ""

            Me.Close()
            Starting_Menu.Show()

        End If
    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Dim result As Integer
        result = MsgBox("Are you sure you want to exit the application?", vbYesNo + vbExclamation, "Exiting Apllication")

        If result = vbYes Then
            Application.Exit()
        End If
    End Sub


End Class