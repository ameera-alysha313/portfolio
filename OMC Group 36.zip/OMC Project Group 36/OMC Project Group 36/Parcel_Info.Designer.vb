﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Parcel_Info
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.txtRoomNumber = New System.Windows.Forms.TextBox()
        Me.txtNotes = New System.Windows.Forms.TextBox()
        Me.cboBlock = New System.Windows.Forms.ComboBox()
        Me.btnCancel = New System.Windows.Forms.Button()
        Me.btnNext = New System.Windows.Forms.Button()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.rbNA = New System.Windows.Forms.RadioButton()
        Me.rbLarge = New System.Windows.Forms.RadioButton()
        Me.rbMedium = New System.Windows.Forms.RadioButton()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.btnBack = New System.Windows.Forms.Button()
        Me.cboVillage = New System.Windows.Forms.ComboBox()
        Me.rbSmall = New System.Windows.Forms.RadioButton()
        Me.txtTrackingNumber = New System.Windows.Forms.TextBox()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.GroupBox1.SuspendLayout()
        Me.SuspendLayout()
        '
        'txtRoomNumber
        '
        Me.txtRoomNumber.Location = New System.Drawing.Point(411, 439)
        Me.txtRoomNumber.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.txtRoomNumber.Name = "txtRoomNumber"
        Me.txtRoomNumber.Size = New System.Drawing.Size(124, 26)
        Me.txtRoomNumber.TabIndex = 47
        '
        'txtNotes
        '
        Me.txtNotes.Location = New System.Drawing.Point(111, 504)
        Me.txtNotes.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.txtNotes.Multiline = True
        Me.txtNotes.Name = "txtNotes"
        Me.txtNotes.Size = New System.Drawing.Size(335, 69)
        Me.txtNotes.TabIndex = 46
        '
        'cboBlock
        '
        Me.cboBlock.FormattingEnabled = True
        Me.cboBlock.Location = New System.Drawing.Point(111, 460)
        Me.cboBlock.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.cboBlock.Name = "cboBlock"
        Me.cboBlock.Size = New System.Drawing.Size(136, 28)
        Me.cboBlock.TabIndex = 45
        '
        'btnCancel
        '
        Me.btnCancel.Location = New System.Drawing.Point(252, 627)
        Me.btnCancel.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.btnCancel.Name = "btnCancel"
        Me.btnCancel.Size = New System.Drawing.Size(102, 40)
        Me.btnCancel.TabIndex = 44
        Me.btnCancel.Text = "Cancel"
        Me.btnCancel.UseVisualStyleBackColor = True
        '
        'btnNext
        '
        Me.btnNext.Location = New System.Drawing.Point(423, 638)
        Me.btnNext.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.btnNext.Name = "btnNext"
        Me.btnNext.Size = New System.Drawing.Size(102, 40)
        Me.btnNext.TabIndex = 43
        Me.btnNext.Text = "Next"
        Me.btnNext.UseVisualStyleBackColor = True
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Location = New System.Drawing.Point(294, 442)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(116, 20)
        Me.Label11.TabIndex = 42
        Me.Label11.Text = "Room Number:"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(42, 508)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(55, 20)
        Me.Label10.TabIndex = 41
        Me.Label10.Text = "Notes:"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(44, 470)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(52, 20)
        Me.Label9.TabIndex = 40
        Me.Label9.Text = "Block:"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(39, 419)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(60, 20)
        Me.Label8.TabIndex = 39
        Me.Label8.Text = "Village:"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold)
        Me.Label7.Location = New System.Drawing.Point(193, 359)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(176, 25)
        Me.Label7.TabIndex = 38
        Me.Label7.Text = "Delivery Address"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(39, 321)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(107, 20)
        Me.Label6.TabIndex = 37
        Me.Label6.Text = "Delivery Date:"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold)
        Me.Label5.Location = New System.Drawing.Point(176, 274)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(203, 25)
        Me.Label5.TabIndex = 36
        Me.Label5.Text = "Delivery Information"
        '
        'rbNA
        '
        Me.rbNA.AutoSize = True
        Me.rbNA.Location = New System.Drawing.Point(25, 122)
        Me.rbNA.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.rbNA.Name = "rbNA"
        Me.rbNA.Size = New System.Drawing.Size(60, 24)
        Me.rbNA.TabIndex = 35
        Me.rbNA.TabStop = True
        Me.rbNA.Text = "N/A"
        Me.rbNA.UseVisualStyleBackColor = True
        '
        'rbLarge
        '
        Me.rbLarge.AutoSize = True
        Me.rbLarge.Location = New System.Drawing.Point(25, 89)
        Me.rbLarge.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.rbLarge.Name = "rbLarge"
        Me.rbLarge.Size = New System.Drawing.Size(75, 24)
        Me.rbLarge.TabIndex = 34
        Me.rbLarge.TabStop = True
        Me.rbLarge.Text = "Large"
        Me.rbLarge.UseVisualStyleBackColor = True
        '
        'rbMedium
        '
        Me.rbMedium.AutoSize = True
        Me.rbMedium.Location = New System.Drawing.Point(25, 56)
        Me.rbMedium.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.rbMedium.Name = "rbMedium"
        Me.rbMedium.Size = New System.Drawing.Size(90, 24)
        Me.rbMedium.TabIndex = 33
        Me.rbMedium.TabStop = True
        Me.rbMedium.Text = "Medium"
        Me.rbMedium.UseVisualStyleBackColor = True
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(193, 28)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(170, 25)
        Me.Label3.TabIndex = 31
        Me.Label3.Text = "Parcel Info Form"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(39, 107)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(133, 20)
        Me.Label2.TabIndex = 30
        Me.Label2.Text = "Tracking Number:"
        '
        'btnBack
        '
        Me.btnBack.Location = New System.Drawing.Point(67, 627)
        Me.btnBack.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.btnBack.Name = "btnBack"
        Me.btnBack.Size = New System.Drawing.Size(102, 40)
        Me.btnBack.TabIndex = 28
        Me.btnBack.Text = "Back"
        Me.btnBack.UseVisualStyleBackColor = True
        '
        'cboVillage
        '
        Me.cboVillage.FormattingEnabled = True
        Me.cboVillage.Location = New System.Drawing.Point(111, 415)
        Me.cboVillage.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.cboVillage.Name = "cboVillage"
        Me.cboVillage.Size = New System.Drawing.Size(136, 28)
        Me.cboVillage.TabIndex = 27
        '
        'rbSmall
        '
        Me.rbSmall.AutoSize = True
        Me.rbSmall.Location = New System.Drawing.Point(26, 24)
        Me.rbSmall.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.rbSmall.Name = "rbSmall"
        Me.rbSmall.Size = New System.Drawing.Size(73, 24)
        Me.rbSmall.TabIndex = 26
        Me.rbSmall.TabStop = True
        Me.rbSmall.Text = "Small"
        Me.rbSmall.UseVisualStyleBackColor = True
        '
        'txtTrackingNumber
        '
        Me.txtTrackingNumber.Location = New System.Drawing.Point(43, 131)
        Me.txtTrackingNumber.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.txtTrackingNumber.Name = "txtTrackingNumber"
        Me.txtTrackingNumber.Size = New System.Drawing.Size(247, 26)
        Me.txtTrackingNumber.TabIndex = 25
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.rbNA)
        Me.GroupBox1.Controls.Add(Me.rbLarge)
        Me.GroupBox1.Controls.Add(Me.rbMedium)
        Me.GroupBox1.Controls.Add(Me.rbSmall)
        Me.GroupBox1.Location = New System.Drawing.Point(354, 77)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(171, 158)
        Me.GroupBox1.TabIndex = 48
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Parcel Size"
        '
        'Parcel_Info
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(9.0!, 20.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(575, 750)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.txtRoomNumber)
        Me.Controls.Add(Me.txtNotes)
        Me.Controls.Add(Me.cboBlock)
        Me.Controls.Add(Me.btnCancel)
        Me.Controls.Add(Me.btnNext)
        Me.Controls.Add(Me.Label11)
        Me.Controls.Add(Me.Label10)
        Me.Controls.Add(Me.Label9)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.btnBack)
        Me.Controls.Add(Me.cboVillage)
        Me.Controls.Add(Me.txtTrackingNumber)
        Me.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.Name = "Parcel_Info"
        Me.Text = "Parcel Info"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents txtRoomNumber As TextBox
    Friend WithEvents txtNotes As TextBox
    Friend WithEvents cboBlock As ComboBox
    Friend WithEvents btnCancel As Button
    Friend WithEvents btnNext As Button
    Friend WithEvents Label11 As Label
    Friend WithEvents Label10 As Label
    Friend WithEvents Label9 As Label
    Friend WithEvents Label8 As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents rbNA As RadioButton
    Friend WithEvents rbLarge As RadioButton
    Friend WithEvents rbMedium As RadioButton
    Friend WithEvents Label3 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents btnBack As Button
    Friend WithEvents cboVillage As ComboBox
    Friend WithEvents rbSmall As RadioButton
    Friend WithEvents txtTrackingNumber As TextBox
    Friend WithEvents GroupBox1 As GroupBox
End Class
