﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class ADMIN_Review_Form
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(ADMIN_Review_Form))
        Me.txtReview = New System.Windows.Forms.TextBox()
        Me.btnBack = New System.Windows.Forms.Button()
        Me.btn5Star = New System.Windows.Forms.PictureBox()
        Me.btn4Star = New System.Windows.Forms.PictureBox()
        Me.btn1Star = New System.Windows.Forms.PictureBox()
        Me.btn2Star = New System.Windows.Forms.PictureBox()
        Me.btn3Star = New System.Windows.Forms.PictureBox()
        Me.btnNext = New System.Windows.Forms.Button()
        CType(Me.btn5Star, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.btn4Star, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.btn1Star, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.btn2Star, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.btn3Star, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'txtReview
        '
        Me.txtReview.Location = New System.Drawing.Point(158, 239)
        Me.txtReview.Multiline = True
        Me.txtReview.Name = "txtReview"
        Me.txtReview.ReadOnly = True
        Me.txtReview.Size = New System.Drawing.Size(520, 230)
        Me.txtReview.TabIndex = 4
        '
        'btnBack
        '
        Me.btnBack.BackColor = System.Drawing.Color.Orange
        Me.btnBack.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnBack.ForeColor = System.Drawing.Color.White
        Me.btnBack.Location = New System.Drawing.Point(34, 532)
        Me.btnBack.Name = "btnBack"
        Me.btnBack.Size = New System.Drawing.Size(144, 51)
        Me.btnBack.TabIndex = 5
        Me.btnBack.Text = "Back"
        Me.btnBack.UseVisualStyleBackColor = False
        '
        'btn5Star
        '
        Me.btn5Star.Image = Global.OMC_Project_Group_36.My.Resources.Resources.star
        Me.btn5Star.Location = New System.Drawing.Point(582, 131)
        Me.btn5Star.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.btn5Star.Name = "btn5Star"
        Me.btn5Star.Size = New System.Drawing.Size(96, 85)
        Me.btn5Star.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.btn5Star.TabIndex = 19
        Me.btn5Star.TabStop = False
        '
        'btn4Star
        '
        Me.btn4Star.Image = Global.OMC_Project_Group_36.My.Resources.Resources.star
        Me.btn4Star.Location = New System.Drawing.Point(480, 131)
        Me.btn4Star.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.btn4Star.Name = "btn4Star"
        Me.btn4Star.Size = New System.Drawing.Size(96, 85)
        Me.btn4Star.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.btn4Star.TabIndex = 18
        Me.btn4Star.TabStop = False
        '
        'btn1Star
        '
        Me.btn1Star.BackColor = System.Drawing.Color.Transparent
        Me.btn1Star.Image = Global.OMC_Project_Group_36.My.Resources.Resources.star
        Me.btn1Star.InitialImage = Global.OMC_Project_Group_36.My.Resources.Resources.star
        Me.btn1Star.Location = New System.Drawing.Point(174, 131)
        Me.btn1Star.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.btn1Star.Name = "btn1Star"
        Me.btn1Star.Size = New System.Drawing.Size(96, 85)
        Me.btn1Star.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.btn1Star.TabIndex = 17
        Me.btn1Star.TabStop = False
        '
        'btn2Star
        '
        Me.btn2Star.Image = Global.OMC_Project_Group_36.My.Resources.Resources.star
        Me.btn2Star.Location = New System.Drawing.Point(276, 131)
        Me.btn2Star.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.btn2Star.Name = "btn2Star"
        Me.btn2Star.Size = New System.Drawing.Size(96, 85)
        Me.btn2Star.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.btn2Star.TabIndex = 16
        Me.btn2Star.TabStop = False
        '
        'btn3Star
        '
        Me.btn3Star.Image = Global.OMC_Project_Group_36.My.Resources.Resources.star
        Me.btn3Star.Location = New System.Drawing.Point(379, 131)
        Me.btn3Star.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.btn3Star.Name = "btn3Star"
        Me.btn3Star.Size = New System.Drawing.Size(96, 85)
        Me.btn3Star.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.btn3Star.TabIndex = 15
        Me.btn3Star.TabStop = False
        '
        'btnNext
        '
        Me.btnNext.BackColor = System.Drawing.Color.Orange
        Me.btnNext.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnNext.ForeColor = System.Drawing.Color.White
        Me.btnNext.Location = New System.Drawing.Point(637, 532)
        Me.btnNext.Name = "btnNext"
        Me.btnNext.Size = New System.Drawing.Size(139, 51)
        Me.btnNext.TabIndex = 20
        Me.btnNext.Text = "Next"
        Me.btnNext.UseVisualStyleBackColor = False
        '
        'ADMIN_Review_Form
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(9.0!, 20.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.MidnightBlue
        Me.ClientSize = New System.Drawing.Size(825, 651)
        Me.Controls.Add(Me.btnNext)
        Me.Controls.Add(Me.btn5Star)
        Me.Controls.Add(Me.btn4Star)
        Me.Controls.Add(Me.btn1Star)
        Me.Controls.Add(Me.btn2Star)
        Me.Controls.Add(Me.btn3Star)
        Me.Controls.Add(Me.btnBack)
        Me.Controls.Add(Me.txtReview)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "ADMIN_Review_Form"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Customer Reviews"
        CType(Me.btn5Star, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.btn4Star, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.btn1Star, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.btn2Star, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.btn3Star, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents txtReview As TextBox
    Friend WithEvents btnBack As Button
    Friend WithEvents btn5Star As PictureBox
    Friend WithEvents btn4Star As PictureBox
    Friend WithEvents btn1Star As PictureBox
    Friend WithEvents btn2Star As PictureBox
    Friend WithEvents btn3Star As PictureBox
    Friend WithEvents btnNext As Button
End Class
